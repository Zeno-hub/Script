/**
@credit Rijalganzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import { watchFile, unwatchFile } from 'fs'
import fs from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
const Func = await import('./system/function.js')

global.func = Func

global.setting = {
  clearSesi: false,
  clearTmp: true,
  addReply: true,
  idgc: '120363418194471219@g.us'
}

global.limit = 50

global.info = {
  nomerbot: '62882009507703',
  pairingNumber: '62882009507703',
  figlet: '',
  nomorwa: '62882009507703',
  nameown: 'Rijalganzz',
  nomerown: '62882009507703',
  packname: 'Rijalganzz md',
  author: 'Rijalganzz',
  namebot: 'Furina Md',
  domain: '-',
  ptla: '-',
  nestid: '5',
  egg: '15',
  loc: '1',
  setpairing: 'FURINAXD',
  wm: 'Furina Md X Rijalganzz',
  stickpack: 'Whatsapp',
  stickauth: 'Rijalganzz',
  idch: '120363424912126266@newsletter',
  namechannel: 'Random Musik',
  jid: '120363399903419548@s.whatsapp.net'
}

global.media = {
  ppKosong: 'https://i.ibb.co/3Fh9V6p/avatar-contact.png',
  didyou: 'https://telegra.ph/file/fdc1a8b08fe63520f4339.jpg',
  rulesBot: 'https://telegra.ph/file/afcfa712bd09f4fcf027a.jpg',
  thumbnail: 'https://cdn.yupra.my.id/yp/8owl6tzg.jpg',
  thumb: 'https://telegra.ph/file/69b47ff9c959f244e0382-74d80b517d6d64a6a0.png',
  logo: 'https://telegra.ph/file/07428fea2fd4dccaab65f.jpg',
  unReg: 'https://telegra.ph/file/ef02d1fdd59082d05f08d.jpg',
  registrasi: 'https://telegra.ph/file/0169f000c9ddc7c3315ff.jpg',
  confess: 'https://telegra.ph/file/03cabea082a122abfa5be.jpg',
  access: 'https://files.catbox.moe/12ugym.png',
  tqto: 'https://telegra.ph/file/221aba241e6ededad0fd5.jpg',
  spotify: 'https://telegra.ph/file/d888041549c7444f1212b.jpg',
  weather: 'https://telegra.ph/file/5b35ba4babe5e31595516.jpg',
  gempaUrl: 'https://telegra.ph/file/03e70dd45a9dc628d84c9.jpg',
  akses: 'https://files.catbox.moe/apol2w.jpg',
  bank: 'https://files.catbox.moe/yt1lp3.jpg',
  wel: 'https://telegra.ph/file/9dbc9c39084df8691ebdd.mp4',
  good: 'https://telegra.ph/file/1c05b8c019fa525567d01.mp4',
  sound: 'https://files.catbox.moe/b2uw6o.mp3'
}

global.url = {
  sig: 'https://chat.whatsapp.com/IxlDjH5B5VBFR6nqjhcE0M',
  sgh: 'https://chat.whatsapp.com/IxlDjH5B5VBFR6nqjhcE0M',
  sgc: 'https://chat.whatsapp.com/IxlDjH5B5VBFR6nqjhcE0M'
}

global.pay = {
  dana: '083870750111',
  gopay: '083870750111',
  spay: '083870750111',
  pulsa: '083870750111'
}

global.msg = {
  wait: '⏱️ *Mohon bersabar*\n\> Sedang menjalankan perintah dari *User*!',
  eror: '🤖 *Information Bot*\n\> Mohon maaf atas ketidaknyamanan dalam menggunakan *Furina Md*. Ada kesalahan dalam sistem saat menjalankan perintah.'
}

global.apiId = {
  smm: '0tyea5-qty7i9-d4jusl-ouxmfd-be6jyv',
  lapak: '2cP6UH149uO2na8y4BFHFDTFzjzbXSNh'
}

global.api = {
  user: '-',
  screet: '-',
  uptime: '-',
  xyro: 'vRFLiyLPWu',
  lol: 'GataDios',
  smm: '0tyea5-qty7i9-d4jusl-ouxmfd-be6jyv',
  lapak: '2cP6UH149uO2na8y4BFHFDTFzjzbXSNh',
  prodia: 'ca30661d-1df1-4855-a5bd-4daa5a987972',
  bing: '12qV0YMFj2WcUsbyEz3Xbi4XqBpsV1t7W_0r1BQWDu2wZYit4d68vInmsyasdkJLcrE1NUkvugPdcABWV-AUa7iQeuoAyA1XYP5_V-VlqgVPTX8lrkFv7rDOVduM0EhTPlBOeU87aVHsSLZYrdqHMXhz2bdBgehv4i3CQ0ee15pEkMCos5lN2RJ3I8lbWc81nEd8UE_3jpByh6mbDjj23DQ'
}

global.btc = 'FURINA MD'
global.kevin = 'apikey'
global.vin = 'b2jePNec'

global.APIs = {
  nightTeam: 'https://api.tioxy.my.id',
  smm: 'https://smmnusantara.id',
  lapak: 'https://panel.lapaksosmed.com',
  btc: 'https://api.botcahx.eu.org',
  vin: 'https://api.betabotz.eu.org',
  rijalganzz: 'https://rijalganzz.web.id',
}

global.APIKeys = {
  nightTeam: 'Tio'
}

global.owner = [
  ['62882009507703', 'Rijalganzz', true],
  ['-', 'owner', true],
]
global.mods = []
global.prems = ['62882009507703']
global.multiplier = 69

global.flok = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'Halo'
  },
  message: {
    locationMessage: {
      name: `🎉 ${global.info.namebot} || ${global.info.nameown} ✨`,
      jpegThumbnail: ''
    }
  }
}

global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      agility: '🤸‍♂️',
      arc: '🏹',
      armor: '🥼',
      bank: '🏦',
      bibitanggur: '🍇',
      bibitapel: '🍎',
      bibitjeruk: '🍊',
      bibitmangga: '🥭',
      bibitpisang: '🍌',
      bow: '🏹',
      bull: '🐃',
      cat: '🐈',
      chicken: '🐓',
      cow: '🐄',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      superior: '💼',
      crystal: '🔮',
      darkcrystal: '♠️',
      diamond: '💎',
      emerald: '💚',
      gold: '👑',
      iron: '⛓️',
      exp: '✉️',
      pointxp: '📧',
      level: '🧬',
      limit: '🌌',
      fishingrod: '🎣',
      pickaxe: '⛏️',
      sword: '⚔️',
      knife: '🔪',
      magicwand: '⚕️',
      upgrader: '🧰',
      health: '❤️',
      stamina: '⚡',
      strength: '🦹‍♀️',
      agility: '🤸‍♂️',
      intelligence: '🧠',
      mana: '🪄',
      potion: '🥤',
      pet: '🎁',
      petfood: '🍖',
      money: '💵',
      gems: '🍀',
      rock: '🪨',
      string: '🕸️',
      trash: '🗑',
      wood: '🪵',
      keygold: '🔑',
      keyiron: '🗝️',
      dog: '🐕',
      fox: '🦊',
      horse: '🐎',
      lion: '🦁',
      tiger: '🐅',
      snake: '🐍',
      dragon: '🐉',
      elephant: '🐘',
      giraffe: '🦒'
    }

    let results = Object.keys(emot)
      .map(v => [v, new RegExp(v, 'gi')])
      .filter(v => v[1].test(string))

    return results.length ? emot[results[0][0]] : ''
  }
}

global.nomerbot = info.nomerbot
global.pairingNumber = info.pairingNumber
global.nomorwa = info.nomorwa
global.nameown = info.nameown
global.nomerown = info.nomerown
global.packname = info.packname
global.author = info.author
global.namebot = info.namebot
global.wm = info.wm
global.stickpack = info.stickpack
global.stickauth = info.stickauth

global.ppKosong = media.ppKosong
global.didyou = media.didyou
global.rulesBot = media.rulesBot
global.thumbnail = media.thumbnail
global.thumb = media.thumb
global.logo = media.logo
global.unReg = media.unReg
global.registrasi = media.registrasi
global.confess = media.confess
global.access = media.access
global.tqto = media.tqto
global.spotify = media.spotify
global.weather = media.weather
global.gempaUrl = media.gempaUrl
global.akses = media.akses
global.wel = media.wel
global.good = media.good

global.sig = url.sig
global.sgh = url.sgh
global.sgc = url.sgc

global.pdana = pay.dana
global.wait = msg.wait
global.eror = msg.eror
global.uptime = api.uptime

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})