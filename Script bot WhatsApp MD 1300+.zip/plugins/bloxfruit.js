/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import axios from 'axios';
import fs from 'fs';

let handler = async (m, { conn }) => {
  const url = `${global.APIs.rijalganzz}/search/bloxfruit`;

  try {
    const { data } = await axios.get(url);
    if (!data || !data.status || !data.data) {
      return m.reply('❌ ɢᴀɢᴀʟ ᴍᴇɴɢᴀᴍʙɪʟ ᴅᴀᴛᴀ API.');
    }

    let normalStockList = [];
    let mirageStockList = [];

    for (let item of data.data) {
      let line = `- ${item.name} | ${item.priceDolar} | ${item.priceR}`;
      if (item.type.includes('Normal')) normalStockList.push(line);
      if (item.type.includes('Mirage')) mirageStockList.push(line);
    }

    const message = `
🌟 *ɴᴏʀᴍᴀʟ sᴛᴏᴄᴋ* 🌟
ʀᴇғʀᴇsʜᴇs ᴇᴠᴇʀʏ 𝟺 ʜᴏᴜʀs
ʟɪsᴛ ғʀᴜɪᴛ:
${normalStockList.join('\n')}

✨ *ᴍɪʀᴀɢᴇ sᴛᴏᴄᴋ* ✨
ʀᴇғʀᴇsʜᴇs ᴇᴠᴇʀʏ 𝟸 ʜᴏᴜʀs
ʟɪsᴛ ғʀᴜɪᴛ:
${mirageStockList.join('\n')}
    `.trim();

    await conn.sendMessage(m.chat, {
      text: message,
      contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        externalAdReply: {
          title: `${global.namebot} © 𝟸𝟶𝟸𝟻`,
          body: `ʙʏ ${global.nameown}`,
          thumbnail: fs.readFileSync('./media/thumbnail.jpg'),
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply('❌ ɢᴀɢᴀʟ ᴍᴇɴɢᴀᴍʙɪʟ ᴅᴀᴛᴀ sᴛᴏᴄᴋ.');
  }
};

handler.command = ['stockfruits', 'stockfruit'];
handler.help = ['stockfruit'];
handler.tags = ['info', 'bypass'];
handler.premium = false;

export default handler;

export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}