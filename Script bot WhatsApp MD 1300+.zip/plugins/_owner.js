/**
@credit RijalGanzz
@Furina Md
@Whatsapp Bot
wa.me/62882009507703
**/
const fkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      remoteJid: "0@s.whatsapp.net",
      fromMe: false,
      id: "Halo",
    },
    message: {
      conversation: "❤️kamu dari mana sih aku kangen❤️"
    }
};
let handler = m => m

handler.before = async function (m) {
    if (m.chat.endsWith('broadcast')) return
    if (m.fromMe || !m.isGroup) return

    if (m.sender === '62882009507703@s.whatsapp.net') {
        let user = global.db.data.users[m.sender] ?? {}
        let last = user.pc || 0
        let now = +new Date()
        if (now - last < 600000) return

        let halo = `halo developer furina md @${m.sender.split('@')[0]} 👋🏻`
        await conn.sendMessage(m.chat, {
            text: halo,
            mentions: [m.sender],
            quoted: fkontak
        })

        user.pc = now
    }
}

export default handler