import fetch from 'node-fetch';
import uploader from '../lib/uploadImage.js';

const handler = m => m;

handler.before = async function (m, { conn }) {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!global.antiporn) return;
    if (!/image/.test(mime)) return;

    try {
        let media = await q.download();
        let url = await uploader(media);

        let response = await fetch(`https://api.botcahx.eu.org/api/tools/nsfw-detect?url=${url}&apikey=${btc}`);
        let res = await response.json();

        if (res.result.labelName === 'Porn') {
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            });
            m.reply('Astagfirullah🤲');
        }
    } catch (e) {
        console.error(e);
    }
};

export default handler;