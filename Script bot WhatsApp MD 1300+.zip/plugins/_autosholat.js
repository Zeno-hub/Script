import axios from 'axios';
import Jimp from 'jimp';
import fs from 'fs';

const handler = async (m, { conn, command, args, isAdmin, isGroup }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya bisa digunakan di dalam grup.");
    if (!isAdmin) return m.reply("❌ Hanya admin yang bisa mengaktifkan atau menonaktifkan fitur ini.");

    let id = m.chat;
    
    if (command === "autosholat") {
        if (!args[0]) {
            return m.reply("⚠️ Gunakan: *.autosholat on/off/status*\n\nContoh:\n`.autosholat on`\n`.autosholat off`\n`.autosholat status`");
        }

        if (args[0] === "on") {
            if (conn.autosholat && conn.autosholat[id]) return m.reply("✅ Fitur Auto Sholat sudah aktif.");

            let lokasi = 'DKI JAKARTA DAN SEKITARNYA';
            let jdwl = await jadwalsholat(lokasi);
            conn.autosholat = conn.autosholat ?? {};
            conn.autosholat[id] = { lastSent: {}, jdwl };

            return m.reply("✅ Fitur Auto Sholat telah *diaktifkan*! Pengingat sholat akan dikirimkan secara otomatis.");
        } 
        
        if (args[0] === "off") {
            if (!conn.autosholat || !conn.autosholat[id]) return m.reply("⚠️ Fitur Auto Sholat belum diaktifkan.");
            
            delete conn.autosholat[id];
            return m.reply("✅ Fitur Auto Sholat telah *dinonaktifkan*.");
        }

        if (args[0] === "status") {
            if (conn.autosholat && conn.autosholat[id]) {
                return m.reply("✅ Fitur Auto Sholat saat ini *aktif*.");
            } else {
                return m.reply("⚠️ Fitur Auto Sholat saat ini *tidak aktif*.");
            }
        }
    }
};

handler.command = /^autosholat$/i;
handler.help = ["autosholat on", "autosholat off", "autosholat status"];
handler.tags = ["group"];
handler.admin = true;
handler.group = true;

export default handler;

export async function before(m, { conn, participants }) {
    conn.autosholat = conn.autosholat ?? {};
    
    let lokasi = 'DKI JAKARTA DAN SEKITARNYA';
    let id = m.chat;

    if (!conn.autosholat[id]) return;

    if (!fs.existsSync('./media/jdw.png')) {
        let jdw = await jadwalsholat(lokasi);
        await image(jdw.shubuh, jdw.dhuhur, jdw.ashar, jdw.maghrib, jdw.isya, lokasi);
    } else {
        let result = conn.autosholat[id].jdwl;
        const date = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
        const timeNow = date.toTimeString().slice(0, 5);

        for (const [sholat, waktu] of Object.entries(result)) {
            if (timeNow === waktu && conn.autosholat[id].lastSent[sholat] !== waktu) {
                let message = {
                    audio: { url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ' },
                    mimetype: 'audio/mp4',
                    ptt: true,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            mediaType: 1,
                            mediaUrl: '',
                            title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
                            body: `🕑 ${waktu}`,
                            sourceUrl: '',
                            thumbnail: await fs.readFileSync('./media/jdw.png'),
                            renderLargerThumbnail: true
                        }
                    }
                };

                await conn.sendMessage(m.chat, message, { quoted: m, mentions: participants.map(a => a.id) });

                conn.autosholat[id].lastSent[sholat] = waktu;
            }
        }
    }
}

async function jadwalsholat(kota) {
    try {
        const { data } = await axios.get(`https://api.aladhan.com/v1/timingsByCity?city=${kota}&country=Indonesia&method=8`);
        return {
            shubuh: data.data.timings.Fajr,
            dhuhur: data.data.timings.Dhuhr,
            ashar: data.data.timings.Asr,
            maghrib: data.data.timings.Maghrib,
            isya: data.data.timings.Isha
        };
    } catch (e) {
        return 'error 404';
    }
}

async function image(sh, dh, as, ma, is, lok) {
    const image = await Jimp.read('https://telegra.ph/file/8e791e4a13e80881584dc.jpg');
    const font = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);
    const wil = await Jimp.loadFont(Jimp.FONT_SANS_64_BLACK);
    
    image.print(font, 550, 223, sh);
    image.print(font, 550, 321, dh);
    image.print(font, 550, 392, as);
    image.print(font, 550, 481, ma);
    image.print(font, 550, 571, is);
    image.print(wil, 870, 391, lok);
    
    await image.writeAsync('./media/jdw.png');
}