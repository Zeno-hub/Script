import axios from "axios";
import FormData from "form-data";
import cheerio from "cheerio";

let handler = async (m, { conn, text }) => {
    if (!text) throw "Contoh: .pindl https://id.pinterest.com/pin/575757133623547811/";

    try {
        m.reply("Mohon tunggu, sedang memproses...");

        // Panggil fungsi untuk mendapatkan metadata
        const result = await pindl(text);

        // Validasi respons dan data
        if (!result || !result.medias || result.medias.length === 0) {
            throw "Media tidak ditemukan atau link tidak valid.";
        }

        const { medias, title } = result;

        // Filter untuk video mp4
        let mp4 = medias.filter(v => v.extension === "mp4");

        if (mp4.length !== 0) {
            // Kirim video dengan kualitas terbaik
            const video = mp4[0];
            await conn.sendMessage(
                m.chat,
                {
                    video: { url: video.url },
                    caption: `*${title}*\nQuality: ${video.quality}\nSize: ${await toSize(video.size)}`
                },
                { quoted: m }
            );
        } else {
            // Jika tidak ada video, kirim file lainnya
            await conn.sendFile(m.chat, medias[0].url, "", `*${title}*`, m);
        }
    } catch (e) {
        console.error("Error:", e);
        m.reply("Terjadi kesalahan saat memproses link. Pastikan link valid dan coba lagi.");
    }
};

handler.help = ["pindownload"];
handler.command = /^(pind(own)?l(oad)?)$/i;
handler.tags = ["downloader"];

export default handler;

// Fungsi untuk mengunduh media Pinterest
async function pindl(url) {
    try {
        const apiUrl = "https://pinterestdownloader.io/frontendService/DownloaderService";

        // Kirim permintaan ke API
        const response = await axios.get(apiUrl, {
            params: { url }
        });

        if (!response.data || response.data.error) {
            throw "Gagal mendapatkan data dari API.";
        }

        return response.data; // Kembalikan data yang berhasil diambil
    } catch (error) {
        console.error("Error fetching data:", error.message);
        throw "Gagal mengambil data. Silakan coba lagi nanti.";
    }
}

// Fungsi konversi ukuran file (bytes ke KB/MB/GB)
async function toSize(bytes) {
    const units = ["B", "KB", "MB", "GB"];
    let size = bytes;
    let unit = 0;

    while (size >= 1024 && unit < units.length - 1) {
        size /= 1024;
        unit++;
    }
    return `${size.toFixed(2)} ${units[unit]}`;
}