import fetch from 'node-fetch'

let timeout = 120000
let poin = 4999

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.game = conn.game ? conn.game : {}
    let id = 'tebakgambar-' + m.chat

    if (id in conn.game)
        return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.game[id][0])

    try {
        let res = await fetch(`${global.APIs.rijalganzz}/game/tebakgambar`)
        let data = await res.json()

        if (!data.status || !data.result || !data.result.length)
            throw new Error('Gagal memuat soal dari API')

        let json = data.result[Math.floor(Math.random() * data.result.length)]

        let caption = `
${json.deskripsi}

⏱ Timeout: *${(timeout / 1000).toFixed(2)} detik*
💡 Ketik ${usedPrefix}hgamb untuk bantuan
🎁 Bonus: ${poin} XP
`.trim()

        conn.game[id] = [
            await conn.sendMessage(
                m.chat,
                { image: { url: json.img }, fileName: 'tebakgambar.jpg', mimetype: 'image/jpeg', caption },
                { quoted: m }
            ),
            json,
            poin,
            setTimeout(() => {
                if (conn.game[id]) {
                    conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.game[id][0])
                    delete conn.game[id]
                }
            }, timeout)
        ]
    } catch (e) {
        console.error(e)
        conn.reply(m.chat, 'Terjadi kesalahan saat mengambil data dari API.', m)
    }
}

handler.help = ['tebakgambar']
handler.tags = ['game']
handler.command = /^tebakgambar$/i

handler.onlyprem = true
handler.game = true

export default handler