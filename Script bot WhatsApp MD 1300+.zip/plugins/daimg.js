import fetch from 'node-fetch';

let handler = async (m, { conn, text, command, prefix }) => {
  if (!text) {
    return m.reply(`*Contoh :* .daimg future girl, mecha 4K`);
  }

  await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

  const generateImage = async (prompt) => {
    try {
      const apiUrl = `https://api.vreden.my.id/api/text2img?query=${encodeURIComponent(prompt)}`;
      const response = await fetch(apiUrl, { method: 'GET' });

      if (!response.ok) {
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        // If response is JSON, process as JSON
        const responseData = await response.json();
        if (responseData.status && responseData.buffer) {
          return Buffer.from(responseData.buffer, 'base64'); // Convert base64 to Buffer
        } else {
          throw new Error('Received invalid response from API');
        }
      } else {
        const imageBuffer = await response.arrayBuffer();
        return Buffer.from(imageBuffer);
      }
    } catch (error) {
      console.error('Fetch error:', error);
      throw error;
    }
  };

  try {
    let imgBuffer = await generateImage(text);
    if (!imgBuffer) {
      throw new Error('Image buffer is undefined');
    }

    const imgMsg = { image: imgBuffer, caption: `Nih Om` };
    await conn.sendMessage(m.chat, imgMsg, { quoted: m });
  } catch (error) {
    console.error('Error in generateImage:', error);
    m.reply('Terjadi kesalahan saat menghasilkan gambar. Silakan coba lagi.');
  }
};

handler.help = ['daimg'];
handler.tags = ['tools'];
handler.command = /^daimg/i;

export default handler;