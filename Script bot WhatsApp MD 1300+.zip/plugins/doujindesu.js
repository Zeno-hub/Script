import fetch from 'node-fetch';
import cheerio from 'cheerio';

let handler = async (m, { text }) => {
  if (!text) return m.reply('Masukkan judul doujin yang ingin dicari.\nContoh:\n.doujindesu shinmai');

  const query = encodeURIComponent(text);
  const url = `https://doujindesu.tv/?s=${query}`;

  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
    });

    const html = await res.text();
    const $ = cheerio.load(html);

    let results = [];
    $('.bsx').each((i, el) => {
      const title = $(el).find('.tt').text().trim();
      const link = $(el).find('a').attr('href');
      const thumb = $(el).find('img').attr('src');
      if (title && link) {
        results.push({ title, link, thumb });
      }
    });

    if (!results.length) return m.reply('Tidak ditemukan hasil untuk pencarian tersebut.');

    let textResult = '🔞 *Hasil Pencarian Doujindesu:*\n\n';
    for (let i = 0; i < Math.min(3, results.length); i++) {
      let item = results[i];
      textResult += `📖 *${item.title}*\n🔗 ${item.link}\n\n`;
    }

    textResult += '_⚠️ Konten NSFW (18+). Harap bijak dalam mengakses._';
    m.reply(textResult);
  } catch (e) {
    console.error(e);
    m.reply('Gagal mengambil data dari Doujindesu.');
  }
};

handler.help = ['doujindesu <judul>'];
handler.tags = ['nsfw', 'doujin'];
handler.command = /^doujindesu$/i;

export default handler;