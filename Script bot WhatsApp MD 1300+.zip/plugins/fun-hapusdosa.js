let handler = async (m, { conn, text, usedPrefix, command }) => {
 
m.reply("dosa lu kebanyakan bang udah ga ketolong")

}
handler.help = ["hapusdosa"]
handler.tag = ["fun"] 
handler.command = ["hapusdosa"];
export default handler;