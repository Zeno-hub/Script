/**
@credit RijalGanzz
@Furina Md
@Whatsapp Bot
wa.me/62882009507703
**/
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from "@whiskeysockets/baileys";
import axios from 'axios';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

const allEndpoints = {
  '1': {
    url: 'https://api-faa.my.id/faa/tofigura?url=',
    name: 'Figura Style V1',
    description: 'Efek figura versi 1 - Classic Style'
  },
  '2': {
    url: 'https://api-faa.my.id/faa/tofigurav2?url=',
    name: 'Figura Style V2',
    description: 'Efek figura versi 2 - Enhanced Style'
  },
  '3': {
    url: 'https://api-faa.my.id/faa/tofigurav3?url=',
    name: 'Figura Style V3',
    description: 'Efek figura versi 3 - Premium Style'
  }
};

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }); 

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    
    if (!mime || mime === 'conversation') {
      return m.reply(`📸 Silakan reply gambar dengan caption *${usedPrefix + command}* untuk mendapatkan 3 hasil figura sekaligus.`);
    }

    if (!mime.startsWith('image/')) {
      return m.reply(`❌ Hanya gambar yang didukung! Format ${mime} tidak valid.`);
    }

    let media = await q.download();
    if (!media || media.length === 0) return m.reply('❌ Gagal mendownload media');

    const maxSize = 10 * 1024 * 1024;
    if (media.length > maxSize) {
      return m.reply(`❌ Ukuran gambar terlalu besar! Maksimal 10MB. Ukuran saat ini: ${(media.length / 1024 / 1024).toFixed(2)}MB`);
    }

    let fileType = await fileTypeFromBuffer(media);
    let ext = fileType?.ext || 'jpg';

    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', media, { filename: `figure_${Date.now()}.${ext}`, contentType: mime });

    let uploadRes;
    try {
      uploadRes = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: {
          ...form.getHeaders(),
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        maxBodyLength: Infinity,
        timeout: 60000
      });
    } catch (err) {
      console.error('Upload gagal:', err);
      throw new Error('❌ Gagal mengunggah gambar ke server');
    }

    let urlFile = uploadRes.data.trim();
    if (!urlFile.startsWith('http')) {
      throw new Error(`❌ Respon upload tidak valid: ${urlFile}`);
    }

    const processingPromises = Object.keys(allEndpoints).map(async (key) => {
        const endpoint = allEndpoints[key];
        const apiUrl = `${endpoint.url}${encodeURIComponent(urlFile)}`;

        try {
            const figureRes = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const buffer = Buffer.from(figureRes.data);
            const resultFileType = await fileTypeFromBuffer(buffer);

            if (!buffer || buffer.length === 0 || !resultFileType || !resultFileType.mime.startsWith('image/')) {
                throw new Error(`Hasil ${endpoint.name} tidak valid`);
            }

            return {
                ...endpoint,
                buffer: buffer,
                resultFileType: resultFileType,
                status: 'success'
            };
        } catch (error) {
            console.error(`Gagal memproses ${endpoint.name}:`, error.message);
            return {
                ...endpoint,
                status: 'failed',
                error: error.message
            };
        }
    });

    const allResults = await Promise.allSettled(processingPromises);
    
    const successfulResults = allResults
        .filter(p => p.status === 'fulfilled' && p.value.status === 'success')
        .map(p => p.value);

    if (successfulResults.length === 0) {
        const allErrors = allResults
            .filter(p => p.status === 'fulfilled' || p.status === 'rejected')
            .map(p => {
                const error = p.status === 'rejected' ? p.reason.message : p.value.error;
                return error;
            })
            .join('; ');

        throw new Error(`Semua konversi Figura gagal. Detail: ${allErrors}`);
    }

    let push = [];

    for (let result of successfulResults) {
        const mediaWa = await prepareWAMessageMedia(
            { image: result.buffer },
            { upload: conn.waUploadToServer }
        );

        push.push({
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `🎨 ${result.name}`, 
                hasMediaAttachment: true,
                ...mediaWa
            }),
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `✅ Deskripsi: ${result.description}\n` +
                      `✅ Ukuran: ${formatBytes(result.buffer.length)}\n` +
                      `✅ Format: ${result.resultFileType.ext.toUpperCase()}`
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: `✨ Hasil Figura oleh ${global.info.namebot}`
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [{
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "👍 Coba Lagi",
                        id: usedPrefix + command 
                    })
                }]
            })
        });
    }

    const successCount = successfulResults.length;
    const bodyText = `🖼️ Hasil Konversi Figura (${successCount} in 3)\n\n` +
                     `Gambar Anda berhasil dikonversi ke ${successCount} gaya figura.\n` +
                     (successCount < 3 ? `Ada ${3 - successCount} fitur yang gagal dan dilewati\n\n` : '') +
                     `Geser ke kanan untuk melihat semua hasilnya.`;

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
                forwardingScore: 256,
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: bodyText 
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `Powered by ${global.info.namebot}`
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [...push]
                    })
                })
            }
        }
    }, { userJid: m.chat, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    
    const reactEmoji = successCount === 3 ? '✅' : '⚠️';
    await conn.sendMessage(m.chat, { react: { text: reactEmoji, key: m.key } });

  } catch (err) {
    console.error('Error Total:', err);
    
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    
    let errorMessage = '❌ Gagal memproses gambar.\n\n';
    
    if (err.message.includes('Semua konversi Figura gagal')) {
         errorMessage += 'Kegagalan Total. Semua 3 fitur figura gagal dikonversi.\n';
         errorMessage += `Detail Error: ${err.message.split('Detail: ')[1] || 'Coba lagi nanti.'}\n`;
    } else if (err.message.includes('timeout')) {
      errorMessage += 'Proses konversi terlalu lama.\n';
    } else if (err.message.includes('network') || err.message.includes('ECONN')) {
      errorMessage += 'Gagal terhubung ke server.\n';
    } else if (err.message.includes('upload')) {
      errorMessage += 'Gagal mengunggah gambar.\n';
    } else if (err.message.includes('ukuran')) {
      errorMessage += 'Gambar terlalu besar (Maks 10MB).\n';
    } else {
      errorMessage += `Error: ${err.message.replace('Error: ', '')}\n`;
    }
    
    errorMessage += '\nCoba lagi dengan gambar yang berbeda.';
    
    m.reply(errorMessage);
  }
};

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}

handler.help = ['figure'].map(v => v + ' - Konversi gambar ke 3 efek figura sekaligus');
handler.tags = ['aiv2'];
handler.command = /^(figure|figura|tofigure)$/i;
handler.limit = 5;

export default handler;