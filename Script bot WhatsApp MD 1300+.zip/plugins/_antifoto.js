export async function before(m, { isAdmin, isBotAdmin }) {
  if (m.isBaileys && m.fromMe) return true

  if (!global.db.data.chats) global.db.data.chats = {}
  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  if (!global.db.data.chats[m.sender]) global.db.data.chats[m.sender] = {}

  const chat = global.db.data.chats[m.chat]
  const sender = global.db.data.chats[m.sender]
  const isFoto = m.mtype
  const hapus = m.key?.participant
  const bang = m.key?.id

  if (chat.antiFoto && isFoto === "imageMessage") {
    if (isAdmin || !isBotAdmin) {
      return
    }
    m.reply(`*Foto Terdeteksi*\n\nMaaf, foto harus dihapus karena admin mengaktifkan anti foto di chat ini.`)
    return this.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: hapus }})
  }

  return true
}