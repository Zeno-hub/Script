import { Sticker } from 'wa-sticker-formatter';

let handler = async (m, { conn, text }) => {
    let teksMasukan = m.quoted?.text || text || '';
    if (!teksMasukan) return m.reply('Balas pesan atau berikan teks.');

    try {
        const buttonMessage = {
            text: teksMasukan,
            footer: 'Pilih tombol di bawah',
            buttons: [
                { buttonId: `.bratvid ${teksMasukan}`, buttonText: { displayText: 'Jadikan bratvideo' }, type: 1 },
                { buttonId: `.bratip ${teksMasukan}`, buttonText: { displayText: 'Jadikan brat iphone' }, type: 1 },
                { buttonId: `.bratandro ${teksMasukan}`, buttonText: { displayText: 'Jadikan Brat Android' }, type: 1 }
            ],
            headerType: 1
        };

        await conn.sendMessage(m.chat, buttonMessage, { quoted: m });

    } catch (error) {
        console.error('Kesalahan saat mengirim pesan tombol:', error);
        m.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
};

handler.help = ['brat'];
handler.tags = ['tools'];
handler.command = /^brat$/i;

export default handler;