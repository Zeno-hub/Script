let autoPost = {
  active: false,
  interval: 10, // dalam menit
  message: 'Halo semua, ini pesan otomatis dari bot!',
  timer: null,
};

let handler = async (m, { conn, args, command }) => {
  let subcmd = args[0];

  switch (subcmd) {
    case 'on':
      if (autoPost.active) return m.reply('Autopost sudah aktif!');
      autoPost.active = true;

      autoPost.timer = setInterval(async () => {
        let groupsData = await conn.groupFetchAllParticipating();
        let groupIds = Object.keys(groupsData);

        for (let id of groupIds) {
          await conn.sendMessage(id, { text: autoPost.message }).catch(() => {});
        }
      }, autoPost.interval * 60 * 1000);

      m.reply(`Autopost diaktifkan setiap ${autoPost.interval} menit.`);
      break;

    case 'off':
      if (!autoPost.active) return m.reply('Autopost sudah nonaktif.');
      autoPost.active = false;
      clearInterval(autoPost.timer);
      m.reply('Autopost dimatikan.');
      break;

    case 'setmsg':
      if (!args[1]) return m.reply('Masukkan pesan yang ingin dikirim.\nContoh: .autopost setmsg Halo semua!');
      autoPost.message = args.slice(1).join(' ');
      m.reply('Pesan berhasil diubah.');
      break;

    case 'setinterval':
      let menit = parseInt(args[1]);
      if (isNaN(menit) || menit < 1) return m.reply('Masukkan interval dalam menit (minimal 1 menit).');
      autoPost.interval = menit;

      if (autoPost.active) {
        clearInterval(autoPost.timer);
        autoPost.timer = setInterval(async () => {
          let groupsData = await conn.groupFetchAllParticipating();
          let groupIds = Object.keys(groupsData);

          for (let id of groupIds) {
            await conn.sendMessage(id, { text: autoPost.message }).catch(() => {});
          }
        }, autoPost.interval * 60 * 1000);
      }

      m.reply(`Interval diubah menjadi ${menit} menit.`);
      break;

    default:
      m.reply(`Gunakan perintah:
.autopost on - Aktifkan autopost
.autopost off - Matikan autopost
.autopost setmsg [pesan] - Ubah pesan
.autopost setinterval [menit] - Ubah interval`);
  }
};

handler.help = ['autopost'];
handler.command = /^autopost$/i;
handler.tags = ['tools'];
handler.owner = true
export default handler;