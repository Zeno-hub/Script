let handler = async (m) => {

let anu =`
╭╾• 〔 TUTORIAL BOT  〕
│ 
├〘 Tutorial BOT 〙
├⛶ *乂User Wajib Register*
│⛶ *乂Ketik .Daftar Nama.Umur*
│⛶ *乂Bot Pake Prefix berupa . atau /*
├⛶ *乂Bot Tidak Akan respon Apabila*
├⛶ *乂Tidak Sesuai Prefix/Fitur Bots*
├⛶ *乂Pilihlah Menu Yang Tepat Dan Sesuai*
│⛶ *乂Yang Telah Dibuat Oleh Owner Bot*
│⛶ *乂Bot Rpg Adalah Bot Game Yang Dibuat*
│⛶ *乂Untuk Dimainkan Oleh User/Pengguna*
│⛶ *乂Ada 1000+ Fitur Yang Bisa Kalian Coba*
│⛶ *乂Dan Ada Fitur Ai Untuk Membantu Kalian*
│⛶ *乂Untuk Mengerjakan Tugas/Skripsi*
│⛶ *乂Pertanyaan Lainnya, Yang Ingin Dicari*
│⛶ *乂Beri Jeda Bot Agar Bot Tidak DelayRespon*
│⛶ *乂*
│⛶ *乂*
└─「 *T U T O R I A L B O T* 」`
await m.reply(anu)
}

handler.help = ["bottutor"];
handler.tags = ["info"];
handler.command = /^(bottutor)$/i;
handler.group = true;
export default handler