/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh penggunaan: ${usedPrefix + command} Hai nama aku Putu`

  await m.reply('⏳ Lagi proses bratandro... tunggu bentar')

  let url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false&delay=500`
  let stiker = await sticker(null, url, `${global.namebot} by ${global.nameown}`, `\n\nhttps://wa.me/${global.nomerown}\n\n`)

  await conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
}

handler.help = ['bratandro <teks>']
handler.tags = ['sticker']
handler.command = /^bratandro$/i
handler.limit = true

export default handler