/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import fs from 'fs'
import path from 'path'
import { tmpdir } from 'os'
import { fileURLToPath } from 'url'
import { GoogleGenerativeAI } from '@google/generative-ai'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

let handler = async (m, { conn, text }) => {
  if (!text) throw `❌ Masukkan prompt!\n\nContoh: .aiedit ubah jadi lebih estetik`

  let quotedMsg = m.quoted || m
  let mime = (quotedMsg.msg || quotedMsg).mimetype || ''
  let imgBuffer = null

  if (!mime && quotedMsg.message?.imageMessage) {
    mime = quotedMsg.message.imageMessage.mimetype
  } else if (!mime && m.message?.imageMessage) {
    mime = m.message.imageMessage.mimetype
  }

  if (!/image\/(jpe?g|png)/.test(mime)) {
    throw '❌ Balas atau kirim gambar dengan format jpg/png!'
  }

  try {
    imgBuffer = await quotedMsg.download()
  } catch {
    throw '❌ Gagal download gambar. Pastikan reply gambar asli (bukan stiker atau dokumen).'
  }

  await m.reply('🧠 Otw diedit sesuai prompt kamu...')

  try {
    const base64Image = imgBuffer.toString('base64')
    const genAI = new GoogleGenerativeAI('AIzaSyB8T-3WnKqDbK3GSYYUtTiyDfIV-vBxoPw')

    const model = genAI.getGenerativeModel({
      model: 'gemini-2.0-flash-exp-image-generation',
      generationConfig: {
        responseModalities: ['Text', 'Image']
      }
    })

    const contents = [
      { text },
      {
        inlineData: {
          mimeType: mime,
          data: base64Image
        }
      }
    ]

    const response = await model.generateContent(contents)

    const parts = response?.response?.candidates?.[0]?.content?.parts
    if (!parts) throw '❌ Gagal mendapatkan respons dari AI.'

    let resultImage = null
    for (const part of parts) {
      if (part.inlineData) resultImage = Buffer.from(part.inlineData.data, 'base64')
    }

    if (!resultImage) throw '❌ Gagal memproses hasil gambar.'

    const tmpPath = path.join(tmpdir(), `editai_${Date.now()}.png`)
    fs.writeFileSync(tmpPath, resultImage)

    await conn.sendMessage(m.chat, {
      image: { url: tmpPath },
      caption: `*Edit selesai!*`
    }, { quoted: m })

    setTimeout(() => fs.unlinkSync(tmpPath), 30_000)

  } catch (e) {
    console.error(e)
    throw `❌ Error\nLogs error : ${e}`
  }
}

handler.command = ['aiedit', 'editai']
handler.help = ['aiedit <prompt>']
handler.tags = ['ai']

export default handler