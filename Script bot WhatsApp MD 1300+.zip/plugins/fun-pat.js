import { sticker } from '../lib/sticker.js'
import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    try {
        let mentions = []
        if (m.quoted?.sender) mentions.push(m.quoted.sender)
        if (!mentions.length) mentions.push(m.sender)

        let res = await fetch('https://api.waifu.pics/sfw/pat')
        let json = await res.json()
        let { url } = json

        let stiker = await sticker(
            null,
            url,
            `+${m.sender.split('@')[0]} patted on ${mentions.map(user => (user === m.sender) ? 'alguien' : `+${user.split('@')[0]}`).join(', ')}`
        )

        await conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m })
    } catch (e) {
        console.error(e)
    }
}

handler.command = /^(pat)$/i
export default handler