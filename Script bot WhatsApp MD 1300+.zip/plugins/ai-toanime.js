import axios from 'axios'
import cheerio from "cheerio"

let handler = async (m, { conn, usedPrefix, text, args,command }) => {
	let q = m.quoted ? m.quoted : m;
	let mime = (q.msg || q).mimetype || q.mediaType || "";
    let mime_ = `Kirim/Reply Gambar Dengan Caption ${usedPrefix + command}`

if (!mime) throw mime_
if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;
	let media = await q.download()   
    let cap = '*Result from* : ' + usedPrefix + command
try {
await m.react('🔮')
let res = await toanime(media);
await conn.sendFile(m.chat, res, '', cap, m)
await m.react('✨')
} catch (e) {
throw eror
}
}
handler.command = ['jadianime','toanime']
handler.help = ["toanime"];
handler.tags = ["process"];
handler.limit = true;
handler.register = true

export default handler;

async function toanime(buffer) {
let base = axios.create({ baseURL: 'https://imageupscaler.com/image-to-anime/' });
  let { data } = await base.get('/');
  const $ = cheerio.load(data);
  const nonce = $('#process_nonce').val();
  const base64String = Buffer.from(buffer, 'binary').toString('base64');
  let { data: ress } = await base.post(
    'https://imageupscaler.com/wp-admin/admin-ajax.php', 
    new URLSearchParams({
      action: 'processing_images_adv',
      nonce: nonce,
      function: 'image-to-anime',
      'mediaData[0][fileSrc]': `data:image/png;base64,${base64String}`,
      'mediaData[0][fileName]': 'IMG-Anime0087.jpg',
      'parameters[upscale-type]': 'anime',
      'parameters[save-format]': 'auto'
    }).toString()
  );
let $result = cheerio.load(ress)
return $result(".block-after img").attr("src")
}