/**
@credit RijalGanzz
@Furina Md
@Whatsapp Bot
wa.me/62882009507703
**/
import axios from 'axios';

const fkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      remoteJid: "0@s.whatsapp.net",
      fromMe: false,
      id: "Halo",
    },
    message: {
      conversation: `Nih Video Nya Kak Dari ${global.namebot} 🍎`
    }
};

const furina = async (m, { conn, args }) => {
  if (!args[0]) return conn.reply(m.chat, 'Ketik link Facebook-nya, contoh:\n.fb https://www.facebook.com/share/r/1E3TC9HLxG/', m, { quoted: fkontak });

  const url = args[0];
  await conn.reply(m.chat, 'Tunggu sebentar kak...', m, { quoted: fkontak });

  try {
    const res = await axios.get(global.APIs.rijalganzz + '/download/facebook?url=' + encodeURIComponent(url));
    const json = res.data;

    if (!json.status || !json.result || !json.result.media) {
      throw new Error('Gagal mengambil video. Link tidak valid atau video tidak tersedia.');
    }

    const { title, duration, media } = json.result;

    await conn.sendMessage(m.chat, {
      video: { url: media },
      caption: `📽 *${title}*\n⏱ Durasi: ${duration}`,
      mimetype: 'video/mp4',
      fileName: 'facebook-video.mp4'
    }, { quoted: m });

  } catch (error) {
    console.error('Error:', error.message);
    await conn.reply(m.chat, `Terjadi kesalahan: ${error.message}`, m, { quoted: fkontak });
  }
};

furina.help = ['facebook', 'fb'];
furina.tags = ['downloader'];
furina.command = /^(facebook|fbdl|fb|facebookdl)$/i;
furina.limit = true;
furina.register = true;

export default furina;