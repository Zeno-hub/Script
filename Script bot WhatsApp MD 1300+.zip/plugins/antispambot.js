let spamCounter = {} // Menyimpan data spam per grup dan user
let antispamStatus = global.antispamStatus = global.antispamStatus || {} // Menyimpan status aktif/tidaknya fitur per grup
const MAX_SPAM = 3
const INTERVAL = 8000 // 8 detik

let handler = async (m, { conn, args, isAdmin, isOwner, command }) => {
    const id = m.chat
    const sender = m.sender

    // Handle perintah .antispam on/off
    if (/^\.?antispam$/i.test(command)) {
        if (!m.isGroup) return m.reply('❗Fitur ini hanya untuk grup.')
        if (!isAdmin && !isOwner) return m.reply('❗Hanya admin yang bisa mengatur fitur ini.')

        if (!args[0]) return m.reply('Ketik *.antispam on* untuk menyalakan, atau *.antispam off* untuk mematikan.')

        const on = args[0].toLowerCase() === 'on'
        antispamStatus[id] = on
        return m.reply(`✅ Fitur antispam sekarang *${on ? 'AKTIF' : 'NONAKTIF'}* di grup ini.`)
    }
}
handler.all = async function (m, { conn }) {
    if (!m.isGroup) return
    if (!antispamStatus[m.chat]) return
    if (!m.text) return

    const id = m.chat
    const sender = m.sender
    const now = Date.now()

    spamCounter[id] = spamCounter[id] || {}
    const user = spamCounter[id][sender] || { lastText: '', lastTime: 0, count: 0 }

    if (m.text === user.lastText && (now - user.lastTime < INTERVAL)) {
        user.count++
    } else {
        user.count = 1
        user.lastText = m.text
    }
    user.lastTime = now
    spamCounter[id][sender] = user

    if (user.count >= MAX_SPAM) {
        user.count = 0
        try {
            await conn.sendMessage(id, {
                text: `🚫 *@${sender.split('@')[0]}* dikeluarkan karena spam lebih dari ${MAX_SPAM}x!`,
                mentions: [sender]
            })
            await conn.groupParticipantsUpdate(id, [sender], 'remove')
        } catch (e) {
            await conn.sendMessage(id, { text: '❗Gagal mengeluarkan anggota. Mungkin bot bukan admin.' })
        }
    }
}

handler.help = ['antispam on', 'antispam off']
handler.tags = ['group']
handler.command = /^antispam$/i
handler.admin = true
handler.group = true

export default handler