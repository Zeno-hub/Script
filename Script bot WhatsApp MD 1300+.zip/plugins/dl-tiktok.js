/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import axios from 'axios'

let furina = async (m, { text, usedPrefix, command, conn }) => {
  if (!text) return conn.reply(m.chat, `Penggunaan: ${usedPrefix}${command} <URL TikTok>`, m, { quoted: m })

  try {
    const quotedMsg = m.quoted ? m.quoted : m
    await conn.reply(m.chat, global.msg.wait, m, { quoted: quotedMsg })

    const res = await axios.get(`${global.APIs.rijalganzz}/download/tiktok-v2?url=${encodeURIComponent(text)}`)
    const json = res.data

    if (!json?.status || !json.result?.play) throw new Error("Gagal mendapatkan video TikTok")

    const videoUrl = json.result.play
    const audioUrl = json.result.music
    const title = json.result.title || "Tidak ada judul"
    const author = json.result.author?.nickname || json.creator || "Tidak diketahui"
    const duration = json.result.duration || 0
    const likes = json.result.stats?.digg_count || 0
    const comments = json.result.stats?.comment_count || 0
    const shares = json.result.stats?.share_count || 0
    const profilePhoto = json.result.author?.avatar || json.result.cover

    await conn.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: `
🎬 *Judul*    : ${title}
👤 *Pembuat*   : ${author}
⏱️ *Durasi*    : ${duration} detik
❤️ *Suka*      : ${likes.toLocaleString()}
💬 *Komentar*  : ${comments.toLocaleString()}
🔗 *Dibagikan* : ${shares.toLocaleString()}
👨‍💻 *Creator Bot* : ${global.nameown}`,
      thumbnail: { url: profilePhoto }
    }, { quoted: quotedMsg })

    if (audioUrl) {
      await conn.sendMessage(m.chat, {
        audio: { url: audioUrl },
        mimetype: "audio/mpeg",
        ptt: false,
        contextInfo: {
          externalAdReply: {
            title: title,
            body: author,
            thumbnailUrl: profilePhoto,
            sourceUrl: global.sgc,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: quotedMsg })
    }

  } catch (err) {
    console.error(err)
    await conn.reply(m.chat, "❌ Gagal mendownload TikTok. Pastikan URL benar.", m, { quoted: m })
  }
}

furina.help = ["tiktok", "tt"].map(v => v + " <url>")
furina.tags = ["downloader"]
furina.premium = false
furina.register = true
furina.limit = 1
furina.command = ["tiktok", "tt"]

export default furina