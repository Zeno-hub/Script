/* jangan hapus wm bang 
script by rijalganzz
base? tio nightmare 
whatsapp 34604216991 ( rijalganzz)
*/

const { proto, generateWAMessageFromContent } = (await import('@whiskeysockets/baileys')).default

let handler = async (m, { conn }) => {
  const data = {
    title: "Menu",
    sections: [
      {
        title: `🤖 ${global.namebot}`,
        rows: [
          { title: ".menu all", description: "ʟɪᴀᴛɪɴ sᴇᴍᴜᴀ ꜰɪᴛᴜʀ ᴅɪ sɪɴɪ, ᴅᴀʀɪ ᴀᴡᴀʟ ꜱᴀᴍᴘᴇ ᴛᴀʜᴀᴘ ᴀᴋʜɪʀ", id: ".allmenu" },
          { title: ".menu ai", description: "ꜰɪᴛᴜʀ ᴀɪ, ᴋᴀʏᴀᴋ ᴛᴀɴʏᴀ ʙᴏᴛ ᴀᴛᴀᴜ ᴇᴅɪᴛ ᴛᴇᴋꜱ", id: ".menu ai" },
          { title: ".menu anime", description: "ɴʏᴀʀɪ ɢᴀᴍʙᴀʀ/ɪɴꜰᴏ ᴀɴɪᴍᴇ ᴅɪꜱɪɴɪ", id: ".menu anime" },
          { title: ".menu audio", description: "ᴜʙᴀʜ sᴜᴀʀᴀ, ᴇꜰᴇᴋ, ᴘɪᴛᴄʜ ᴅᴀɴ ʟᴀɪɴɴʏᴀ", id: ".menu audio" },
          { title: ".menu downloader", description: "ᴅᴏᴡɴʟᴏᴀᴅ ʏᴛ, ɪɢ, ᴛɪᴋᴛᴏᴋ ᴅʟʟ", id: ".menu downloader" },
          { title: ".menu fun", description: "ʜɪʙᴜʀᴀɴ ᴋᴀʏᴀᴋ ᴛᴇʙᴀᴋᴀɴ, ᴍᴇᴍᴇ, ᴅꜱʙ", id: ".menu fun" },
          { title: ".menu game", description: "ᴍᴀᴜ ᴍᴀɪɴɪɴ ɢᴀᴍᴇ ʀᴘɢ ᴀᴛᴀᴜ ʟᴜᴄᴜ²? ɴɪʜ", id: ".menu game" },
          { title: ".menu group", description: "ꜰɪᴛᴜʀ ᴋʜᴜsᴜꜱ ɢʀᴜᴘ, ᴋᴀʏᴀᴋ ᴛᴀɢᴀʟʟ ᴅʟʟ", id: ".menu group" },
          { title: ".menu info", description: "ɪɴꜰᴏɪɴ ꜱᴇᴘᴜᴛᴀʀ ᴜꜱᴇʀ, ʙᴏᴛ ᴅʟʟ", id: ".menu info" },
          { title: ".menu maker", description: "ʙɪᴋɪɴ ꜱᴛɪᴋᴇʀ, ᴛᴇxᴛ ʟᴏɢᴏ, ꜰᴏᴛᴏ ᴅꜱʙ", id: ".menu maker" },
          { title: ".menu owner", description: "ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴀᴊᴀ ɴɪʜ", id: ".menu owner" },
          { title: ".menu premium", description: "ꜰɪᴛᴜʀ ᴘʀᴇᴍɪᴜᴍ ʏᴀɴɢ ɢᴀ ʙɪꜱᴀ ᴅɪᴀᴋꜱᴇꜱ sᴇᴍʙᴀʀᴀɴɢᴀɴ", id: ".menu premium" },
          { title: ".menu quran", description: "ʙᴀᴄᴀᴀɴ ᴀʏᴀᴛ, ᴛᴀꜰꜱɪʀ, ᴀᴜᴅɪᴏ ᴅꜱʙ", id: ".menu quran" },
          { title: ".menu quotes", description: "ᴋᴀᴛᴀ² ʙɪᴊᴀᴋ ᴀᴛᴀᴜ ʀᴀɴᴅᴏᴍ ᴏᴛɪᴠᴀꜱɪ", id: ".menu quotes" },
          { title: ".menu rpg", description: "ᴍᴀɪɴɪɴ ʀᴘɢ ɢᴀᴍᴇ ᴋᴀʏᴀᴋ ʙᴇʀᴘᴇᴛᴜᴀʟᴀɴɢ", id: ".menu rpg" },
          { title: ".menu search", description: "ᴄᴀʀɪɴ ꜱᴇꜱᴜᴀᴛᴜ, ᴛɪɴɢɢᴀʟ ᴋᴇᴛɪᴋ", id: ".menu search" },
          { title: ".menu sound", description: "ꜰɪʟᴛᴇʀ sᴜᴀʀᴀ ᴋᴀʏᴀᴋ ᴄᴇᴘᴀᴛ, ᴘᴇʟᴀɴ, ʙᴀꜱ", id: ".menu sound" },
          { title: ".menu sticker", description: "ᴋᴏɴᴠᴇʀᴛ ꜰᴏᴛᴏ ᴀᴛᴀᴜ ɢɪꜰ ᴋᴇ sᴛɪᴋᴇʀ", id: ".menu sticker" },
          { title: ".menu tools", description: "ᴀʟᴀᴛ ʙᴀɴᴛᴜ ᴋᴀʏᴀᴋ ꜱʜᴏʀᴛ ᴜʀʟ, ᴘɪɴɢ, ᴅʟʟ", id: ".menu tools" },
          { title: ".menu voice", description: "ᴛᴜʙᴇʀ ꜱᴜᴀʀᴀ ᴋᴇ ᴄᴇᴡᴇᴋ ɪᴍᴜᴛ ᴀᴛᴀᴜ ʟᴀɪɴɴʏᴀ", id: ".menu voice" },
          { title: ".menu wallpaper", description: "ᴄᴀʀɪɴ ᴡᴀʟʟᴘᴀᴘᴇʀ ʙᴜᴀᴛ ʜᴘ ʟᴜ", id: ".menu wallpaper" }
        ]
      }
    ]
  }

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: 'ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɴɪʜ'
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʀɪᴊᴀʟɢᴀɴᴢᴢ'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: 'ᴄʟɪᴄᴋ ʜᴇʀᴇ',
            subtitle: '',
            hasMediaAttachment: false
          }),
          contextInfo: {
            forwardingScore: 9999,
            isForwarded: false,
            mentionedJid: conn.parseMention(m.sender)
          },
          externalAdReply: {
            showAdAttribution: true,
            renderLargerThumbnail: false,
            mediaType: 1
          },
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
              name: 'single_select',
              buttonParamsJson: JSON.stringify(data)
            }]
          })
        })
      }
    }
  }, {})

  conn.relayMessage(m.chat, msg.message, {})
}

handler.help = ['menulist']
handler.tags = ['main']
handler.command = /^(listmenu|menulist)$/i

export default handler