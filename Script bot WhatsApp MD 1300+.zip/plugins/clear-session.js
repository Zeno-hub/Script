import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, command }) => {
  let sessionPath = './session' // ganti sesuai dengan path sesimu

  if (!fs.existsSync(sessionPath)) return m.reply('❌ Folder session tidak ditemukan.')

  try {
    fs.rmSync(sessionPath, { recursive: true, force: true })
    await m.reply('✅ Session berhasil dihapus. Bot akan keluar agar kamu bisa scan ulang.')
    process.exit(0) // keluar dari proses supaya saat start ulang muncul QR
  } catch (err) {
    console.error(err)
    await m.reply('❌ Gagal menghapus session:\n' + err.message)
  }
}

handler.help = ['clearsession']
handler.tags = ['owner']
handler.command = /^clearsession$/i
handler.owner = true // hanya owner yang bisa pakai

export default handler