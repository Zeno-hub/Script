/* jangan hapus wm bang 
script by rijalganzz
base? tio nightmare 
whatsapp 62882009507703 ( rijalganzz)
*/
import axios from 'axios'
import { proto, generateWAMessageContent, generateWAMessageFromContent } from '@whiskeysockets/baileys'

const Rijal = async (m, { conn, text, usedPrefix, command }) => {
  if (m._tkslide) return
  m._tkslide = true

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent(
      { image: { url } },
      { upload: conn.waUploadToServer }
    )
    return imageMessage
  }

  if (!text)
    return m.reply(`Masukkan URL TikTok Slide!\nContoh: ${usedPrefix + command} https://vt.tiktok.com/xxxxx`)

  await conn.sendMessage(m.chat, { text: global.msg.wait }, { quoted: m })

  try {
    const api = `https://api.botcahx.eu.org/api/download/tiktokslide?url=${encodeURIComponent(text)}&apikey=${global.btc}`
    const { data } = await axios.get(api)

    if (!data || !data.result?.images?.length)
      return m.reply('❌ Tidak ada slide yang ditemukan.')

    const slides = data.result.images
    let cards = []

    for (let i = 0; i < slides.length; i++) {
      const imageMsg = await createImage(slides[i])
      cards.push({
        body: { text: `✅ Slide ${i + 1} dari ${slides.length}` },
        footer: { text: `TikTok Slide\n\n© 2025 ${global.info.nameown}` },
        header: { hasMediaAttachment: true, imageMessage: imageMsg },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({
                display_text: 'Lihat di TikTok',
                url: text,
                merchant_url: text
              })
            }
          ]
        }
      })
    }

    const carousel = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadataVersion: 2,
              deviceListMetadata: {}
            },
            interactiveMessage: {
              body: { text: 'Berikut adalah slide dari video TikTok kamu:' },
              footer: { text: '' },
              header: { hasMediaAttachment: false },
              carouselMessage: { cards }
            }
          }
        }
      },
      {}
    )

    await conn.relayMessage(m.chat, carousel.message, { messageId: carousel.key.id })
  } catch (err) {
    console.error(err)
    m.reply(global.msg.error)
  }
}

Rijal.tags = ['downloader']
Rijal.command = /^(tt|tiktok)(slide|ges|geser)$/i
Rijal.premium = false
Rijal.limit = 2

export default Rijal