import fetch from 'node-fetch';

let bpink = [];

// Fungsi untuk memuat data secara asinkron
async function loadBpink() {
  try {
    const res = await fetch('https://raw.githubusercontent.com/arivpn/dbase/master/kpop/blekping.txt');
    const txt = await res.text();
    bpink = txt.split('\n');
  } catch (error) {
    console.error('Error loading Blackpink images:', error);
  }
}

// Memuat data Blackpink pada saat pertama kali
loadBpink();

let handler = async (m, { conn }) => {
  // Memastikan data telah dimuat
  if (bpink.length === 0) {
    throw 'Data Blackpink belum dimuat. Silakan coba lagi nanti.';
  }

  // Memilih gambar acak dari daftar bpink
  let img = bpink[Math.floor(Math.random() * bpink.length)];

  // Memastikan gambar ada
  if (!img) throw 'Gambar tidak ditemukan';

  // Mengirim gambar
  await conn.sendFile(m.chat, img, '', 'Nih Kak', m, 0, {
    thumbnail: await (await fetch(img)).buffer()
  });
};

// Metadata handler
handler.help = ['blackpink'];
handler.tags = ['asupan'];
handler.limit = true;
handler.register = true;
handler.command = /^(bpink|bp|blackpink)$/i;

export default handler;