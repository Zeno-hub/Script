import axios from 'axios'
import ffmpeg from 'fluent-ffmpeg'
import fs from 'fs'
import path from 'path'

let handler = async (m, { text, conn, usedPrefix, command }) => {
    if (!text) return m.reply(`📌 Masukkan judul lagu!\n\nContoh:\n${usedPrefix + command} mellow koplo`)

    const sanitize = s => s.replace(/[\\/:*?"<>|]/g, '').trim()

    const mp3ToOgg = async (buffer) => {
        const tmpIn = path.join('./tmp', `tmp_in_${Date.now()}.mp3`)
        const tmpOut = path.join('./tmp', `tmp_out_${Date.now()}.ogg`)
        fs.writeFileSync(tmpIn, buffer)
        return new Promise((resolve, reject) => {
            ffmpeg(tmpIn)
                .audioCodec('libopus')
                .format('ogg')
                .on('end', () => {
                    const outBuf = fs.readFileSync(tmpOut)
                    fs.unlinkSync(tmpIn)
                    fs.unlinkSync(tmpOut)
                    resolve(outBuf)
                })
                .on('error', err => reject(err))
                .save(tmpOut)
        })
    }

    try {
        await m.reply(`🔍 Mencari lagu *${text}* di YouTube...`)

        const searchUrl = `${global.APIs.rijalganzz}/search/youtube?q=${encodeURIComponent(text)}`
        const { data: search } = await axios.get(searchUrl)

        if (!search.status || !Array.isArray(search.result) || search.result.length === 0)
            return m.reply('❌ Tidak ditemukan hasil pencarian.')

        const vid = search.result[0]
        const url = vid.link
        const title = vid.title
        const author = global.info.nameown
        const cover = vid.imageUrl

        const apiUrl = `https://rynekoo-api.hf.space/downloader/youtube/v1?url=${encodeURIComponent(url)}&format=mp3`

        await m.reply(`🎧 *${title}*\n👨‍💻 ${author}\n🕒 ${vid.duration}\n\n⏳ Mengunduh dan mengkonversi...`)

        const res = await axios.get(apiUrl)
        const data = res.data

        if (!data.success || !data.result?.downloadUrl)
            throw new Error('Gagal mendapatkan link audio.')

        const audioUrl = data.result.downloadUrl
        const audioRes = await axios.get(audioUrl, {
            responseType: 'arraybuffer',
            timeout: 120000
        })

        const buf = Buffer.from(audioRes.data)
        const oggBuf = await mp3ToOgg(buf)
        const safeTitle = sanitize(title)
        const filename = `${safeTitle}_128kbps.ogg`.slice(0, 160)

        await conn.sendMessage(global.info.idch, {
            audio: oggBuf,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            fileName: filename,
            contextInfo: {
                externalAdReply: {
                    title: title,
                    body: author,
                    thumbnailUrl: cover,
                    sourceUrl: url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: null })

    } catch (err) {
        console.error('[PLAYCH ERROR]', err)
        await m.reply(`❌ Gagal memutar lagu.\n> ${err.message}`)
    }
}

handler.help = ['playch <judul>']
handler.tags = ['owner']
handler.command = /^playch$/i
handler.owner = true

export default handler