let handler = async (m, { conn, isRegistered }) => {
  if (!isRegistered) return m.reply(`*Maaf kak, kamu belum terdaftar nih! Ketik .daftar dulu yaa biar bisa pakai fitur ini!* 😁`);
  try {
    const res = await fetch('https://api.vreden.my.id/api/meme?category=cumsluts');
    const json = await res.json();
    const imageUrl = json.result;
    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: 'Nih Meme Nya 😆',
    }, { quoted: m });
  } catch (e) {
    console.error('Error ambil meme:', e);
    m.reply('❌ Waduh, gagal ambil gambar dari API nih kak. Coba lagi bentar lagi ya!');
  }
};

handler.help = ['meme'];
handler.tags = ['fun', 'random'];
handler.command = ['meme'];
handler.register = true; // butuh pendaftaran

export default handler;