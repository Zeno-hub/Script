import fs from 'fs'
let handler = m => m

handler.all = async function (m, { isBlocked }) {
    if (isBlocked) return
    // ketika ada yang invite/kirim link grup di chat pribadi
    if ((m.mtype === 'groupInviteMessage' || m.text.startsWith('Undangan untuk bergabung') || m.text.startsWith('Invitation to join') || m.text.startsWith('Buka tautan ini')) && !m.isBaileys && !m.isGroup) {
    let teks = `Jangan Culik Elaina Om -_-
    
    ⏥ *List harga sewa Bot* ⏥

 *7k/Minggu* 
*12k/bulan*
*50k/Tahun + PremUser 1 Bulan*


Daripada nyulik elaina, mending Sewa Elaina aja :p

Jika berminat hubungi Owner : wa.me/+62882009507703 atau wa.me/+62882009507703
`
    this.reply(m.chat, teks, m)
    const data = global.owner.filter(([id, isCreator]) => id && isCreator)
    this.sendContact(m.chat, data.map(([id, name]) => [id, name]), m)
    }
}

export default handler