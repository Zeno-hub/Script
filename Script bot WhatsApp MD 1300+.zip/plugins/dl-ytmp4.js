/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import fetch from 'node-fetch'

const handler = async (m, { conn, text }) => {
  if (!text) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return
  }

  try {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    const res = await fetch(`${global.APIs.rijalganzz}/download/aio?url=${encodeURIComponent(text)}`)
    const json = await res.json()
    if (!json.status || !json.data || !json.data[0]) throw new Error()

    const { title, videoimg_file_url, video_file_url } = json.data[0]

    await conn.sendMessage(
      m.chat,
      {
        video: { url: video_file_url },
        caption: `🎬 ${title}`,
        thumbnailUrl: videoimg_file_url
      },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  }
}

handler.help = ['ytmp4']
handler.tags = ['downloader']
handler.command = /^(ytmp4|ytvideo)$/i
handler.limit = 5
handler.register = true

export default handler