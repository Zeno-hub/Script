import axios from 'axios';
import crypto from 'crypto';

async function yesai(prompt) {
  const headers = {
    'Content-Type': 'application/json',
    'UniqueId': crypto.randomBytes(16).toString('hex'),
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://www.yeschat.ai/gpt-4o'
  };

  const data = {
    prompt,
    sessionId: crypto.randomBytes(16).toString('hex')
  };

  try {
    const response = await axios.post('https://finechatserver.erweima.ai/api/v1/gpt2/free-gpt2/chat', data, { headers });
    const messages = response.data.match(/\"message\":\"(.*?)\"/g) || [];
    return messages.map(message => message.replace(/\"message\":\"(.*?)\"/, '$1')).join('');
  } catch (error) {
    console.error('Error:', error.message);
    return 'Maaf, terjadi kesalahan dalam mengambil respons dari AI.';
  }
}

let handler = async (m, { conn, command, text }) => {
  if (!text) throw 'What do you want to ask??';
  
  const result = await yesai(text);
  if (result) {
    conn.reply(m.chat, result, m);
  } else {
    conn.reply(m.chat, 'Error </>', m);
  }
}

handler.customPrefix = /^(gpt)/i;
handler.command = new RegExp();

export default handler;