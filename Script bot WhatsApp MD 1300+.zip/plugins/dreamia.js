let handler = async (m, { text, command }) => {
  if (!text) return m.reply('Masukkan prompt teks. Contoh:\n.dreamia pemandangan malam di pegunungan');

  const encodedPrompt = encodeURIComponent(text);
  const dreaminaURL = `https://dreamina.capcut.com/tools/ai-text-to-image?prompt=${encodedPrompt}`;

  m.reply(`🖼️ Berikut adalah tautan untuk menghasilkan gambar berdasarkan prompt Anda:\n${dreaminaURL}\n\nSilakan buka tautan tersebut di browser Anda dan masukkan prompt secara manual untuk menghasilkan gambar.`);
};

handler.help = ['dreamia <teks>'];
handler.tags = ['ai', 'image'];
handler.command = /^dreamia$/i;

export default handler;