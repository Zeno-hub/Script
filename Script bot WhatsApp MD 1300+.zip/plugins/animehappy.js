import fetch from 'node-fetch';
import axios from 'axios'; // Pastikan axios diimpor

let handler = async (m, { command, conn }) => {
    m.reply('Please wait...'); // Menambahkan pesan tunggu

    try {
        const response = await axios.get('https://waifu.pics/api/sfw/happy'); // Menggunakan axios
        const imageUrl = response.data.url; // Menyimpan URL gambar
        
        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: 'Here is your image!' // Ganti dengan pesan yang sesuai
        }, { quoted: m });
        
    } catch (error) {
        console.error(error); // Menampilkan error ke konsol
        m.reply('Error! Something went wrong.'); // Menampilkan pesan error
    }
};
 
handler.command = ['animehappy'];
handler.tags = ['anime'];
handler.help = ['animehappy <kata kunci>'];
handler.limit = true;
handler.register =true;
export default handler;