import fetch from 'node-fetch';
import cheerio from 'cheerio';

let handler = async (m, { text }) => {
  if (!text) return m.reply('Masukkan judul donghua yang ingin dicari.\nContoh:\n.anc Battle Through the Heavens');

  const query = encodeURIComponent(text);
  const searchUrl = `https://anichin.cafe/?s=${query}`;

  try {
    const res = await fetch(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
    });

    const html = await res.text();
    const $ = cheerio.load(html);

    let results = [];
    $('.bsx').each((i, el) => {
      const title = $(el).find('.tt').text().trim();
      const link = $(el).find('a').attr('href');
      const thumb = $(el).find('img').attr('src');
      if (title && link) {
        results.push({ title, link, thumb });
      }
    });

    if (!results.length) return m.reply('Tidak ditemukan hasil untuk pencarian tersebut.');

    // Ambil hasil pertama
    const selected = results[0];

    // Ambil detail dari halaman seri
    const detailRes = await fetch(selected.link, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
    });
    const detailHtml = await detailRes.text();
    const $$ = cheerio.load(detailHtml);

    let downloadLinks = [];
    $$('.eplister li').each((i, el) => {
      const episodeTitle = $$(el).find('.epl-title').text().trim();
      const episodeLink = $$(el).find('a').attr('href');
      if (episodeTitle && episodeLink) {
        downloadLinks.push({ episodeTitle, episodeLink });
      }
    });

    let message = `📺 *${selected.title}*\n🔗 ${selected.link}\n\n📥 *Daftar Episode:*`;
    downloadLinks.slice(0, 5).forEach((ep) => {
      message += `\n- ${ep.episodeTitle}: ${ep.episodeLink}`;
    });

    m.reply(message);
  } catch (e) {
    console.error(e);
    m.reply('Terjadi kesalahan saat menghubungi situs Anichin.');
  }
};

handler.help = ['anc <judul>'];
handler.tags = ['donghua'];
handler.command = /^anc$/i;

export default handler;