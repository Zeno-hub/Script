/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import axios from 'axios'

let furina = async (m, { conn, text, usedPrefix, command }) => {
  if (m.fromMe) return

  if (!text) throw `Masukkan pertanyaan!\n\nContoh: ${usedPrefix + command} Apa itu AI?`

  try {
    await conn.sendMessage(
      m.chat,
      { text: '_「 B E N T A R J I R R 」_' },
      { quoted: m }
    )

    const url = global.APIs.rijalganzz + '/ai/gpt4o?prompt=' + encodeURIComponent(text)
    const { data } = await axios.get(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })

    if (!data || !data.result || typeof data.result !== 'string') throw '❌ Jawaban tidak dikenali dari API.'

    await conn.sendMessage(
      m.chat,
      { text: data.result.trim() },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    throw `❌ Gagal menjawab pertanyaan.\n\nDetail: ${err.message || err}`
  }
}

furina.help = ['furina', 'furinaamd', 'furinaa']
furina.tags = ['tools']
furina.command = /^fur|furina|furinaamd$/i

export default furina