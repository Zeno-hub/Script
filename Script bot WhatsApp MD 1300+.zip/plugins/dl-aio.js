/**
@credit RijalGanzz
@Furina Md
@Whatsapp Bot
wa.me/62882009507703
**/
let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan URL video yang ingin diunduh!'

    try {
        await conn.sendMessage(m.chat, { text: '⏳ Mohon tunggu cik, Bot sedang memproses...' }, { quoted: m })

        let res = await fetch(`${global.APIs.rijalganzz}/download/aio2?url=${encodeURIComponent(text)}`)
        let json = await res.json()

        if (!json.status || !json.result) throw 'Gagal mengambil data video.'

        let result = json.result
        let caption = `🔗 *AIO Downloader*\n\n`
        caption += `🎬 *Judul:* ${result.title || 'Tidak tersedia'}\n`
        caption += `👤 *Author:* ${result.author || 'Tidak diketahui'}\n`
        caption += `🌐 *Sumber:* ${result.source || 'Tidak diketahui'}\n`
        caption += `🆔 *ID:* ${result.id || '-'}\n`

        if (result.thumbnail) {
            await conn.sendMessage(m.chat, {
                image: { url: result.thumbnail },
                caption
            }, { quoted: m })
        }

        const videoHD = result.medias.find(v => v.quality === 'hd_no_watermark')
        const videoNoWM = result.medias.find(v => v.quality === 'no_watermark')
        const audio = result.medias.find(v => v.type === 'audio')

        const videoToSend = videoHD?.url || videoNoWM?.url
        if (videoToSend) {
            await conn.sendMessage(m.chat, {
                video: { url: videoToSend },
                caption: '🎥 Berikut hasil download tanpa watermark:'
            }, { quoted: m })
        }

        if (audio?.url) {
            await conn.sendMessage(m.chat, {
                audio: { url: audio.url },
                mimetype: 'audio/mp4'
            }, { quoted: m })
        }

    } catch (err) {
        console.error(err)
        await conn.sendMessage(m.chat, { text: '❌ Terjadi kesalahan saat memproses video.' }, { quoted: m })
    }
}

handler.help = ['aio']
handler.tags = ['downloader']
handler.command = /^aio$/i

export default handler