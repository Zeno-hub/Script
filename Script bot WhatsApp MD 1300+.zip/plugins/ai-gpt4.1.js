/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import crypto from 'crypto'
import { v4 as uuidv4 } from 'uuid'

const ai = {
  base: {
    api: 'https://toki-41b08d0904ce.herokuapp.com/api/conciseai/chat'
  },
  generateSignature(inputString, key) {
    try {
      const hmac = crypto.createHmac('sha256', 'CONSICESIGAIMOVIESkjkjs32120djwejk2372kjsajs3u293829323dkjd8238293938wweiuwe')
      hmac.update(key + inputString + 'normal')
      return hmac.digest('hex')
    } catch (e) {
      console.error(e)
      return null
    }
  },
  formatMessages(messages) {
    return messages.map(msg => {
      const role = msg.role.toUpperCase()
      return `${role}: ${msg.content}`
    }).join('\n')
  },
  async chat(messages) {
    const user_id = uuidv4().replaceAll('-', '')
    const lastMessage = this.formatMessages(messages)
    const signature = this.generateSignature(lastMessage, user_id)

    const data = new URLSearchParams()
    data.append('question', lastMessage)
    data.append('conciseaiUserId', user_id)
    data.append('signature', signature)
    data.append('previousChats', JSON.stringify([{ a: '', b: lastMessage, c: false }]))
    data.append('model', 'normal')

    const res = await fetch(this.base.api, {
      method: 'POST',
      headers: {
        'User-Agent': 'okhttp/4.10.0',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: data
    })

    if (!res.ok) throw new Error('Gagal menjawab pertanyaan.')
    const json = await res.json()
    return json.answer || 'Tidak ada jawaban ditemukan.'
  }
}
const fkontak = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: '0@s.whatsapp.net',
    fromMe: false,
    id: 'Halo',
  },
  message: {
    conversation: `🎉 ${global.namebot} 2025 🎉`,
  },
};
const handler = async (m, { text, conn }) => {
  if (!text) return conn.reply(m.chat, `
*Usage:* .gpt4.1 <pertanyaan>

*Contoh:* .gpt4.1 tulis kode javascript sederhana
  `.trim(), m, { quoted: fkontak })

  try {
    const messages = [
      { role: 'user', content: text }
    ]

    const reply = await ai.chat(messages)
    conn.reply(m.chat, reply, m, { quoted: fkontak })
  } catch (err) {
    console.error(err)
    conn.reply(m.chat, '⚠️ Terjadi kesalahan saat menjawab.', m, { quoted: fkontak })
  }
}

handler.command = /^gpt4\.1$/i
handler.help = ['gpt4.1 <pertanyaan>']
handler.tags = ['ai']
handler.register = true

export default handler