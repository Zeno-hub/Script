import fetch from 'node-fetch';
import cheerio from 'cheerio';

let handler = async (m, { args, command, text }) => {
  if (!text) return m.reply(`Contoh penggunaan:\n.donghua-search <judul>\n.donghua-detail <id>\n.donghua-download <id>`);

  const endpoints = {
    'donghua-search': {
      url: 'https://codeteam.my.id/view/cfbc95f1-ec83-44d4-aa96-45aca6702076',
      password: 'C$hCV%#!4GGN',
      label: '📈 Hasil Pencarian Donghua'
    },
    'donghua-detail': {
      url: 'https://codeteam.my.id/view/f3e03737-01cc-40ed-b9b8-01947a4003a9',
      password: 'yK(42UHcIeOp',
      label: '📘 Detail Donghua'
    },
    'donghua-download': {
      url: 'https://codeteam.my.id/view/efab8bde-6b4e-4f65-8046-a943f82da4af',
      password: 'XJb!(ZkiLuG^',
      label: '📥 Link Download Donghua'
    }
  };

  let conf = endpoints[command];
  if (!conf) return m.reply('Perintah tidak dikenali.');

  try {
    const formBody = new URLSearchParams();
    formBody.append('password', conf.password);
    formBody.append('query', text);

    const res = await fetch(conf.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formBody.toString()
    });

    const html = await res.text();
    const $ = cheerio.load(html);

    let hasil = $('pre').text().trim() || $('code').text().trim();

    if (!hasil) {
      hasil = $('body').text().trim().slice(0, 1000); // fallback
    }

    if (!hasil) return m.reply('Tidak ditemukan atau respons kosong.');

    m.reply(`${conf.label}\n\n${hasil}`);
  } catch (e) {
    console.error(e);
    m.reply('Terjadi kesalahan saat mengambil data.\n\n' + e.message);
  }
};

handler.help = ['donghua-search <judul>', 'donghua-detail <id>', 'donghua-download <id>'];
handler.tags = ['anime'];
handler.command = /^donghua-(search|detail|download)$/i;

export default handler;