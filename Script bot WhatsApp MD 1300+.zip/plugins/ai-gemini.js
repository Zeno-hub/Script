/* jangan hapus wm bang 
script by rijalganzz
base? tio nightmare 
whatsapp 34604216991 ( rijalganzz)
*/
import axios from 'axios'

let handler = async (m, {
    command,
    usedPrefix,
    conn,
    text,
    args
}) => {
    if (!text) return m.reply('> ✨Hallo ada yang bisa saya bantu?')

    try {
        const result = await gemini(text)

        const { key } = await conn.sendMessage(m.chat, {
            image: { url: 'https://telegra.ph/file/e628941df62f8d0f8c5aa.png' },
            caption: wait
        }, {
            quoted: fVerif,
            mentions: [m.sender]
        })

        await conn.delay(500)
        await conn.sendMessage(m.chat, {
            image: { url: 'https://telegra.ph/file/e628941df62f8d0f8c5aa.png' },
            caption: `\`✨Gemini Ai\`\n\n${sanitizeText(result.reply)}`,
            edit: key
        }, {
            quoted: fVerif,
            mentions: [m.sender]
        })

    } catch (e) {
        throw e
    }
}

handler.help = ["gemini"]
handler.tags = ["ai"]
handler.command = /^(gemini(ai)?)$/i
handler.register = true
handler.premium = true

export default handler

async function gemini(txt) {
    try {
        const { data } = await axios.get(`https://hercai.onrender.com/gemini/hercai?question=${encodeURIComponent(txt)}`, {
            headers: {
                "content-type": "application/json"
            }
        })
        return data
    } catch (e) {
        console.log(e)
    }
}

function sanitizeText(text) {
    const sensitiveWords = ['.backup', '.bakcup', '.bckup']
    for (let word of sensitiveWords) {
        const regex = new RegExp(word.replace(/\./g, '\\.'), 'gi')
        const spaced = word.split('').join(' ')
        text = text.replace(regex, spaced)
    }
    return text
}