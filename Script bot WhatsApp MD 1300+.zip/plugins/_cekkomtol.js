// Utility function to pick a random item from a list
const pickRandom = (list) => {
    return list[Math.floor(Math.random() * list.length)];
};

// Handler function
const handler = async (m, { conn, command, text }) => {
    if (!text) return conn.reply(m.chat, 'Hei, isi namamu dulu dong biar aku bisa cek');

    // Generate the response based on the input name
    const response = `
╭━━━━°「 *Komtol ${text}* 」°
┃
┊• Nama : ${text}
┃• komtol : ${pickRandom(['ih item', 'Belang wkwk', 'Muluss', 'Putih Mulus', 'Black Doff', 'Pink wow', 'Item Glossy'])}
┊• ukuran : ${pickRandom(['5cm', '10cm', '7cm', '9cm', '15cm', '100cm'])}
┃• jembut : ${pickRandom(['lebat', 'ada sedikit', 'gada jembut', 'tipis', 'muluss'])}
╰═┅═━––––––๑`;

    conn.reply(m.chat, response, m);
};

// Command metadata
handler.help = ['cekkontol <nama>'];
handler.tags = ['fun'];
handler.command = /^cekkomtol/i;
handler.register = true
handler.group = true

// Export the handler as a default export
export default handler;