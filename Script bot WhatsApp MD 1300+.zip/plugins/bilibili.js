/*
- Plugins Bstation/Bilibili DL
- Source: https://whatsapp.com/channel/0029Vb1NWzkCRs1ifTWBb13u
- Source Scrape: https://whatsapp.com/channel/0029VbANq6v0VycMue9vPs3u/125
*/
// const axios = require('axios');
// const cheerio = require('cheerio');
// const { exec } = require('child_process');
// const fs = require('node:fs').promises;
// const { promisify } = require('node:util');
// const execPromise = promisify(exec);
import axios from 'axios';
import cheerio from 'cheerio';
import { exec } from 'child_process';
import { promises as fs } from 'node:fs';
import { promisify } from 'node:util';
const execPromise = promisify(exec);

async function handler(m, { text, conn }) {
  if (!text || !/bilibili\.tv|bili\.im/.test(text)) {
    return conn.reply(m.chat, 'Masukkan URL Bilibili yang valid (contoh: https://www.bilibili.tv/video/xxx atau https://bili.im/xxxx)!', m);
  }

  const hasil = await bilibiliDownloader(text);

  if (hasil.status) {
    const { title, description, videoBuffer } = hasil.data;
    const caption = `Judul: ${title}\n\n> Request By ${m.pushName}`;

    await conn.sendMessage(
      m.chat,
      { video: videoBuffer, caption, mimetype: 'video/mp4' },
      { quoted: m }
    );
  } else {
    conn.reply(m.chat, hasil.message, m);
  }
}

handler.help = ['bilibili'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(bilibili|bilidl|bstation)$/i;
handler.limit = true;
handler.register = true;

export default handler;
// module.exports = handler;

async function bilibiliDownloader(url, quality = '480P') {
  try {
    let resolvedUrl = url;
    if (url.includes('bili.im')) {
      const response = await axios.get(url, { maxRedirects: 0, validateStatus: status => status >= 200 && status < 400 });
      if (response.headers.location) {
        resolvedUrl = response.headers.location;
      } else {
        throw new Error('Tidak dapat resolve URL pendek');
      }
    }

    let aid = /\/video\/(\d+)/.exec(resolvedUrl)?.[1];
    if (!aid) throw new Error('ID Video tidak ditemukan');

    const appInfo = await axios.get(resolvedUrl).then(res => res.data);
    const $ = cheerio.load(appInfo);

    const title = $('meta[property="og:title"]').attr('content')?.split('|')[0].trim() || 'No Title';
    const description = $('meta[property="og:description"]').attr('content') || 'No Description';
    const type = $('meta[property="og:video:type"]').attr('content') || 'video/mp4';
    const cover = $('meta[property="og:image"]').attr('content') || '';
    const like = $('.interactive__btn.interactive__like .interactive__text').text() || '0';
    const views = $('.bstar-meta__tips-left .bstar-meta-text').first().text().replace(' Ditonton', '') || '0';

    const response = await axios.get('https://api.bilibili.tv/intl/gateway/web/playurl', {
      params: {
        s_locale: 'id_ID',
        platform: 'web',
        aid,
        qn: '64',
        type: '0',
        device: 'wap',
        tf: '0',
        spm_id: 'bstar-web.ugc-video-detail.0.0',
        from_spm_id: 'bstar-web.homepage.trending.all',
        fnval: '16',
        fnver: '0',
      }
    }).then(res => res.data);

    const selectedVideo = response.data.playurl.video.find(v => v.stream_info.desc_words === quality);
    if (!selectedVideo) throw new Error('Kualitas video tidak ditemukan');
    const videoUrl = selectedVideo.video_resource.url || selectedVideo.video_resource.backup_url[0];
    const audioUrl = response.data.playurl.audio_resource[0].url || response.data.playurl.audio_resource[0].backup_url[0];

    async function downloadBuffer(url) {
      let buffers = [];
      let start = 0;
      let end = 5 * 1024 * 1024;
      let fileSize = 0;

      while (true) {
        const range = `bytes=${start}-${end}`;
        const response = await axios.get(url, {
          headers: {
            DNT: '1',
            Origin: 'https://www.bilibili.tv',
            Referer: 'https://www.bilibili.tv/video/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            Range: range
          },
          responseType: 'arraybuffer'
        });

        if (fileSize === 0) {
          const contentRange = response.headers['content-range'];
          if (contentRange) fileSize = parseInt(contentRange.split('/')[1]);
        }

        buffers.push(Buffer.from(response.data));
        if (end >= fileSize - 1) break;

        start = end + 1;
        end = Math.min(start + 5 * 1024 * 1024 - 1, fileSize - 1);
      }

      return Buffer.concat(buffers);
    }

    const videoBuffer = await downloadBuffer(videoUrl);
    const audioBuffer = await downloadBuffer(audioUrl);

    const tmpVideoPath = 'tmp_video.mp4';
    const tmpAudioPath = 'tmp_audio.mp3';
    const tmpOutputPath = 'tmp_output.mp4';

    await fs.writeFile(tmpVideoPath, videoBuffer);
    await fs.writeFile(tmpAudioPath, audioBuffer);

    const ffmpegCommand = `ffmpeg -i "${tmpVideoPath}" -i "${tmpAudioPath}" -c:v copy -c:a aac -map 0:v:0 -map 1:a:0 -f mp4 "${tmpOutputPath}"`;
    await execPromise(ffmpegCommand);
    const mergedBuffer = await fs.readFile(tmpOutputPath);

    await Promise.all([
      fs.unlink(tmpVideoPath).catch(() => {}),
      fs.unlink(tmpAudioPath).catch(() => {}),
      fs.unlink(tmpOutputPath).catch(() => {})
    ]);

    return {
      status: true,
      message: 'Berhasil mengambil data',
      data: { title, description, type, cover, views, like, videoBuffer: mergedBuffer }
    };
  } catch (error) {
    return {
      status: false,
      message: `Gagal mengambil data: ${error.message}`
    };
  }
}