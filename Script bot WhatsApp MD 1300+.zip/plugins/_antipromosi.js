const handler = m => m;

handler.before = async function(m, { conn, isBotAdmin, isAdmin }) {
  if (
    m.fromMe || 
    m.isBaileys || 
    !m.isGroup || 
    m.sender === conn.user.jid
  ) return true;

  const chat = global.db.data.chats[m.chat];
  const text = (m.text || '').toLowerCase();

  if (chat.antiPromosi) {
    const kataTerlarang = [
      'panel', 'akun', 'join', 'diskon', 'promo', 'minat', 'pm', 'testi',
      'list', 'ready', 'unli', 'sell', 'jual', '5k', '6k', '7k', '8k', '9k',
      '10k', 'sewa', 'open'
    ];
    
    const terdeteksi = kataTerlarang.some(kata => text.includes(kata));
    
    if (terdeteksi) {
      if (isAdmin) return true;
      if (!isBotAdmin) return true;
      
      await conn.sendMessage(m.chat, { delete: m.key });
    }
  }

  return true;
};

export default handler;

export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}