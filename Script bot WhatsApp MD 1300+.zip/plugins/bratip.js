/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
import { Sticker } from 'wa-sticker-formatter'
import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (m.quoted && m.quoted.text) {
    text = m.quoted.text || 'hai'
  } else if (text) {
    text = text
  } else if (!text && !m.quoted) return m.reply('reply / masukan teks')

  try {
    await conn.sendMessage(m.chat, {
      react: {
        text: '⏳',
        key: m.key
      }
    })

    const response = global.APIs.rijalganzz + '/imagecreator/brat?text=' + encodeURIComponent(text)
    let stiker = await createSticker(false, response, global.wm, 10)
    if (stiker) await conn.sendFile(m.chat, stiker, '', '', m, { quoted: m })
  } catch (e) {
    throw e
  }
}

handler.help = ['bratip']
handler.tags = ['tools']
handler.command = /^(bratip)$/i
handler.limit = true
handler.onlyprem = true

export default handler

async function createSticker(img, url, authorName, quality) {
  let stickerMetadata = {
    type: 'full',
    pack: global.wm,
    author: authorName,
    quality
  }
  return (new Sticker(img ? img : url, stickerMetadata)).toBuffer()
}