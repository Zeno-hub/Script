/**
@credit RijalGanzz
@Furina Md
@Whatsapp Bot
wa.me/62882009507703
**/

import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from "@whiskeysockets/baileys"

const handler = async (m, { conn, args, command, usedPrefix }) => {
  if (!args.length) {
    return conn.reply(
      m.chat,
      `🎧 *Cari lagu favoritmu!*\nContoh: ${usedPrefix}${command} nemen ndx aka`,
      m
    )
  }

  const query = args.join(" ")

  try {
    await conn.sendMessage(m.chat, { react: { text: "🔎", key: m.key } })

    const res = await fetch(`${global.APIs.rijalganzz}/search/youtube?q=${encodeURIComponent(query)}`)
    const data = await res.json()

    if (!data.status || !data.result?.length) throw "😔 Lagu tidak ditemukan di YouTube."

    const list = data.result.slice(0, 10)
    const first = list[0]

    const rows = list.map((v, i) => ({
      header: `🎵 ${v.title}`,
      title: `📺 ${v.channel}`,
      description: `⏱️ ${v.duration}`,
      id: `.ytmp3 ${v.link}`
    }))

    await conn.sendMessage(m.chat, {
      product: {
        productImage: { url: first.imageUrl },
        productId: "9999999999999999",
        title: "🎶 Daftar Lagu",
        description: "Klik untuk memutar atau unduh",
        currencyCode: "IDR",
        priceAmount1000: "0",
        retailerId: "ytsearch",
        url: `https://wa.me/${global.info.nomerown}`,
        productImageCount: 1
      },
      businessOwnerJid: `${global.info.nomerown}@s.whatsapp.net`,
      caption: `🎶 *Daftar Lagu Ditemukan!*\n🔍 Pencarian: *${query}*\nPilih lagu favoritmu di bawah 🎧\n> Note: kalo audio nya error pake .play2`,
      footer: "",
      interactiveButtons: [
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "🎧 Pilih Lagu",
            sections: [
              {
                title: "✨ Hasil YouTube",
                highlight_label: "Pilih Salah Satu 🎵",
                rows
              }
            ]
          })
        }
      ]
    }, { quoted: m })

    const url = encodeURIComponent(first.link)
    const apiUrl = `https://rynekoo-api.hf.space/downloader/youtube/v1?url=${url}&format=mp3`

    const fetchRes = await fetch(apiUrl)
    const result = await fetchRes.json()

    if (!result.success || !result.result?.downloadUrl)
      throw "❌ Gagal mendapatkan URL download dari API."

    const { title, downloadUrl, duration, cover } = result.result

    await conn.sendMessage(
      m.chat,
      {
        audio: { url: downloadUrl },
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
        caption: `✅ *Berhasil mengunduh lagu!*\n🎵 *Judul:* ${title}\n⏱️ *Durasi:* ${duration}\n💿 Nikmati musikmu 🎧`,
        contextInfo: {
          externalAdReply: {
            title,
            body: `${global.info.namebot} • Downloader Musik`,
            thumbnailUrl: cover,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    throw `⚠️ Terjadi kesalahan.\n${e.message || e}`
  }
}

handler.help = ["play", "musik", "lagu", "song"].map(v => v + " <judul>")
handler.tags = ["downloader"]
handler.command = /^(play|musik|lagu|song)$/i
handler.limit = true
handler.premium = false
handler.register = true

export default handler