/* jangan hapus wm bang 
script by rijalganzz
base? tio nightmare 
whatsapp 62882009507703 ( rijalganzz)
*/
let handler = async (m, { conn, args, text }) => {
    let user = global.db.data.users[m.sender] || {}
    let name = user.name || 'Pengguna'
    user.subscriber = user.subscriber || 0
    user.money = user.money || 0
    user.like = user.like || 0
    user.liketotal = user.liketotal || 0
    user.bank = user.bank || 0
    user.lastlive = user.lastlive || 0
    user.diamondplaybutton = user.diamondplaybutton || 0
    user.goldplaybutton = user.goldplaybutton || 0
    user.silverplaybutton = user.silverplaybutton || 0

    let aku = user.subscriber
    let kamu = aku.toLocaleString()

    if (aku === 0) return conn.reply(m.chat, `Kamu tidak memiliki akun YouTube, silahkan buat terlebih dahulu,\n\nKetik: .createyt`, m)

    let timie = new Date() - user.lastlive
    if (timie < 600000) return m.reply(`Hari ini kamu sudah live YouTube, silahkan beristirahat\n\nSelama ${clockString(600000 - timie)}`)

    if (!text) return conn.reply(m.chat, `Nama Judul Livenya apa?\nContoh: .live game epep`, m)
    if (text.length > 25) return conn.reply(m.chat, `Panjang judul maksimal 25 karakter`, m)

    let money = 0, subs = 0, like = 0, donate = 0

    if (aku > 10000000) {
        money = random(5000000)
        subs = random(10000)
        like = random(600000)
        donate = random(1500000)
        if (user.diamondplaybutton < 1) {
            user.diamondplaybutton = 1
            conn.reply(m.chat, `*Selamat ${name}*\nkamu mendapatkan Diamond Play Button atas kenaikan ${kamu} subscriber! 🎉💎`, m)
        }
    } else if (aku > 1000000) {
        money = random(500000)
        subs = random(6000)
        like = random(300000)
        donate = random(5500000)
        if (user.goldplaybutton < 1) {
            user.goldplaybutton = 1
            conn.reply(m.chat, `*Selamat ${name}*\nkamu mendapatkan Gold Play Button atas kenaikan ${kamu} subscriber! 🎉🥇`, m)
        }
    } else if (aku > 500000) {
        money = random(230000)
        subs = random(2000)
        like = random(5000)
        donate = random(250000)
    } else if (aku > 100000) {
        money = random(150000)
        subs = random(1000)
        like = random(30000)
        donate = random(150000)
        if (user.silverplaybutton < 1) {
            user.silverplaybutton = 1
            conn.reply(m.chat, `*Selamat ${name}*\nkamu mendapatkan Silver Play Button atas kenaikan ${kamu} subscriber! 🎉🥈`, m)
        }
    } else if (aku > 50000) {
        money = random(80000)
        subs = random(500)
        like = random(3000)
        donate = random(90000)
    } else if (aku > 10000) {
        money = random(60000)
        subs = random(200)
        like = random(2000)
        donate = random(70000)
    } else if (aku > 1000) {
        money = random(30000)
        subs = random(130)
        like = random(1000)
        donate = random(45000)
    } else if (aku > 100) {
        money = random(15000)
        subs = random(90)
        like = random(500)
        donate = random(25000)
    } else {
        money = random(5000)
        subs = random(50)
        like = random(100)
        donate = random(15000)
    }

    user.money += money
    user.subscriber += subs
    user.like += like
    user.liketotal += like
    user.bank += donate
    user.lastlive = new Date() * 1

    let totlike = user.liketotal.toLocaleString()
    let subse = user.subscriber.toLocaleString()
    let mentionedJid = [m.sender]

    let str = `[ 🔴 *LIVE YOUTUBE* ]

*Hasil Dari Streaming*
👤 *Streamer:* @${m.sender.replace(/@.+/, '')}
📹 *Judul Live:* ${text}
💸 *Money:* +${money.toLocaleString()}      
💳 *Donasi:* +${donate.toLocaleString()}
👥 *New Subscriber:* +${subs.toLocaleString()}       
👍🏻 *New Like:* +${like.toLocaleString()}

📊 *Total Like:* ${totlike}
📈 *Total Subscriber:* ${subse}
▬▭▬▭▬▭▬▭▬▭▬▭

Cek akun YouTubemu
ketik .akunyt`

    conn.reply(m.chat, str, m, { contextInfo: { mentionedJid } })
    setTimeout(() => {
        conn.reply(m.chat, `Heii @${m.sender.replace(/@.+/, '')}👋🏻, Subscribersmu menunggumu, ayo live kembali..`, m, {
            contextInfo: { mentionedJid }
        })
    }, 600000)
}

handler.tags = ['rpg', 'game']
handler.help = ['live','streaming']
handler.command = /^(live|streaming)$/i
handler.register = true
handler.group = true
export default handler

function random(max) {
  return Math.floor(Math.random() * max)
}

function clockString(ms) {
    let h = isNaN(ms) ? '60' : Math.floor(ms / 3600000) % 60
    let m = isNaN(ms) ? '60' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '60' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(' : ')
}