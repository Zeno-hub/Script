/**
@credit Tio
@Nightmare MD
@Whatsapp Bot
wa.me/6282285357346
**/

import kode from 'kode-scrape'
const {
    downloader
} = kode;

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) return m.reply(`masukan url story dari instagram`)
    let {
        result
    } = await downloader.igstory(text)
    await conn.sendFile(m.chat, result[0].url, '', null, m)
}
handler.help = ['instagramstory'].map(v => v + ' <username>')
handler.tags = ['downloader']
handler.command = /^(igstory)$/i
handler.register = true
handler.limit = true
export default handler