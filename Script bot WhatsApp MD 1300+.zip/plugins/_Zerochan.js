//WM https://chat.whatsapp.com/KD9epQg7thxHH6CTm0Taw4
//ShizukaMD - KevinDevs
import axios from 'axios';
import cheerio from 'cheerio';

async function zerochan(search) {
    const url = `https://www.zerochan.net/search?q=${encodeURIComponent(search)}`;
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const imageDetails = [];   
        $('.thumb img').each((index, element) => {
            const imgUrl = $(element).attr('data-src') || $(element).attr('src');
            const link = $(element).closest('a').attr('href');
            const title = $(element).attr('alt');

            if (imgUrl && link && title) {
             
                const hdImgUrl = imgUrl.includes("240x") ? imgUrl.replace("240x", "1280x") : imgUrl;
                imageDetails.push({
                    id: `https://www.zerochan.net${link}`,
                    title: title,
                    imgUrl: hdImgUrl
                });
            }
        });

        return imageDetails;
    } catch (error) {
        console.error('Error fetching from Zerochan:', error);
        return [];
    }
}
async function zerochanDetail(url) {
  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const scriptContent = $('script[type="application/ld+json"]').html();
    
    if (!scriptContent) {
      return { error: 'No structured data found for this image.' };
    }
    const jsonData = JSON.parse(scriptContent);
    const title = jsonData.name || 'No title available';
    const downloadLink = jsonData.contentUrl || 'No download link available';
    const description = $('div[id="content"]').find('p').text().trim() || 'No description available.';
    const aliases = $('div[class="search_tags"]').text().trim() || 'No aliases available.';
    const animeUrl = $('a[title="View Anime"]').attr('href') || 'No anime link available.';   
    return { title, downloadLink, description, aliases, animeUrl };
  } catch (error) {
    console.error('Error fetching Zerochan details:', error);
    return { error: 'Failed to fetch details from Zerochan' };
  }
}
const handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, 'Nama Karakter Anime?', m);

  const zerochanft = await zerochan(text);
  if (zerochanft.length === 0) return conn.reply(m.chat, "No results found!", m);
  const pickget = zerochanft[Math.floor(Math.random() * zerochanft.length)];
  const detail = await zerochanDetail(pickget.id);
  if (detail.error) return conn.reply(m.chat, detail.error, m);
  await conn.sendMessage(m.chat, {
    image: { url: detail.downloadLink },
    caption: `*Character Info*\n\n` +
             `${detail.title}\n` +
             `${detail.description}\n` +
             `${detail.aliases}\n` +
             `${detail.animeUrl}\n\n`,
  }, { quoted: m });
};
handler.help = ['zerochan', 'zrchan', 'zchan'];
handler.tags = ['anime'];
handler.command = /^(zerochan|zrchan|zchan)$/i;
handler.register = true;
handler.limit = false

export default handler;