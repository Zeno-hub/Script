import fetch from 'node-fetch';

let handler = async (m, { conn, db }) => {
  let from = m.chat;
  conn.exam = conn.exam ? conn.exam : {};

  // Mengecek apakah user sedang mengikuti ujian
  if (from in conn.exam) {
    conn.sendMessage(m.chat, { text: 'Silahkan selesaikan permainan terlebih dahulu' }, { quoted: conn.exam[from][0] });
    return false;
  }

  // Soal-soal yang diberikan
  let data = [
    { "soal": "Hasil dari -37 x (-78) x 25 adalah ....", "jawaban": "72.150", "a": "-72.150", "b": "72.150", "c": "72.140", "tingkat": "Sekolah Dasar" },
    { "soal": "875 : (-25) : (-7) = n. n adalah ....", "jawaban": "5", "a": "5", "b": "-5", "c": "-25", "tingkat": "Sekolah Dasar" },
    { "soal": "-173 – (-77) + 84 x (-75) : 25 = n. n adalah ....", "jawaban": "341", "a": "351", "b": "-351", "c": "341", "tingkat": "Sekolah Dasar" },
    { "soal": "-183 + (-213) + 396 = n. n adalah ....", "jawaban": "0", "a": "0", "b": "426", "c": "366", "tingkat": "Sekolah Dasar" },
    // Tambahkan soal-soal lainnya di sini...
  ];

  let list = data;
  let random = Math.floor(Math.random() * list.length);
  let json = list[random];

  // Kirim soal ke pengguna dan simpan informasi soal
  conn.exam[from] = [
    await conn.sendMessage(m.chat, { text: `${json.soal}\nA. ${json.a}\nB. ${json.b}\nC. ${json.c}\n\nWaktumu 1 menit untuk menjawab\nSoal tingkat ${json.tingkat}` }, { quoted: m }),
    json.jawaban,  // Menyimpan jawaban yang benar untuk verifikasi
    setTimeout(() => {
      conn.sendMessage(m.chat, { text: 'Waktu habis' }, { quoted: conn.exam[from][0] });
      delete conn.exam[from];  // Hapus soal setelah waktu habis
    }, 60000),  // 1 menit waktu untuk menjawab
    json.a,
    json.b,
    json.c
  ];

  // Mendengarkan jawaban pengguna dengan menangani pesan yang masuk
  conn.onMessage = async (message) => {
    // Memeriksa jika pesan berasal dari chat yang sama dan soal sedang aktif
    if (message.chat === from && message.text) {
      const userAnswer = message.text.trim().toLowerCase(); // Jawaban pengguna
      const correctAnswer = conn.exam[from][1]; // Jawaban yang benar

      if (userAnswer === correctAnswer.toLowerCase()) {
        // Jawaban benar, beri umpan balik
        await conn.sendMessage(m.chat, { text: '✅ Jawaban Anda Benar!' });

        // Tambah bonus pada pengguna (di dalam db)
        let user = db.data.users[m.sender];
        if (!user) {
          user = db.data.users[m.sender] = {};
        }

        user.ipa = user.ipa || 0;  // Menambah skor IPA jika belum ada
        user.ipa += 10;  // Menambahkan bonus untuk jawaban yang benar (bisa sesuaikan)

        // Menambahkan data ke pengguna jika perlu
        await conn.sendMessage(m.chat, { text: `Bonus 10 poin telah ditambahkan. Skor Anda saat ini: ${user.ipa}` });
      } else {
        // Jawaban salah, beri umpan balik
        await conn.sendMessage(m.chat, { text: `❌ Jawaban Anda Salah. Jawaban yang benar adalah: ${correctAnswer}` });
      }

      // Hapus soal dari sesi setelah mendapatkan jawaban
      delete conn.exam[from];
    }
  };
};

handler.tags = ['game'];
handler.command = /^exammtk$/i;
handler.help = ['exammtk'];

export default handler;