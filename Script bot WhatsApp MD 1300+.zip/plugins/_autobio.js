let handler = m => m
handler.all = async function(m) {
    let setting = global.db.data.settings[this.user.jid]
    if (setting.autoBio) {
        let fitur = Object.values(plugins).filter(v => v.help).map(v => v.help).flat(1)
            let _uptime = process.uptime() * 1000
            let uptime = clockString(_uptime);
            let bio = `⏱ ᴀᴋᴛɪꜰ ꜱᴇʟᴀᴍᴀ ${uptime}\n❲ ⏲ᴍᴏᴅᴇ: ${global.opts['ꜱᴇʟꜰ'] ? '⏱ᴘʀɪᴠᴀᴛᴇ' : setting.self ? '⏲ᴘʀɪᴠᴀᴛᴇ' : global.opts['ɢᴄᴏɴʟʏ'] ? '📮ʜᴀɴʏᴀ ɢʀᴜᴘ' : '⏱ᴘᴜʙʟɪᴄ'} ❳ ❲ ${fitur.length} ꜰᴇᴀᴛᴜʀᴇ ❳━❲ 👑ᴏᴡɴᴇʀ: ${global.nameown} ❳━❲ 📍 ${global.botdate} ❳`
            this.updateProfileStatus(bio).catch(_ => _)
    }
}
export default handler

function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    return [d, ' Hari ️', h, ' Jam ', m, ' Menit '].map(v => v.toString().padStart(2, 0)).join('')
}