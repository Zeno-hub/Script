let handler = async (m, {
    text
}) => {
    if (!text) return m.reply('masukan url dari videy.co')
    let result = await cek(text);
    if (result.isValid) {
        await conn.sendFile(m.chat, `https://cdn.videy.co/${result.id}.mp4`, '', "*DOWNLOADER videy.co*", m)
    } else {
        throw "itu bukan link dari videy.co"
    }

}
handler.help = ['videy']
handler.tags = ['downloader']
handler.command = /^(videy)$/i
handler.limit = 7
handler.register = true

export default handler

function cek(url) {
    const pattern = /^https?:\/\/videy\.co\/v\?id=([\w-]+)$/;

    const match = url.match(pattern);
    if (match) {
        return {
            isValid: true,
            id: match[1]
        };
    } else {
        return {
            isValid: false,
            id: null
        };
    }
}