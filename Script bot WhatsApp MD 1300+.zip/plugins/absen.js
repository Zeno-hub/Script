let handler = async (m, { conn, command, args }) => {
  let id = m.chat
  conn.absen = conn.absen || {}

  switch (command) {
    case 'mulaiabsen':
      if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di grup.'
      if (id in conn.absen) throw 'Absen sudah dimulai.'
      conn.absen[id] = [
        [], // unused
        [], // daftar user absen
        args.join(' ') || 'Absen Hari Ini'
      ]
      return m.reply('Sesi absen dimulai! Ketik .absen untuk mengisi.')
    
    case 'absen':
      if (!(id in conn.absen)) throw `Belum ada sesi absen!\nKetik *.mulaiabsen* untuk memulai.`
      let absenList = conn.absen[id][1]
      if (absenList.includes(m.sender)) throw 'Kamu sudah absen!'
      absenList.push(m.sender)
      return m.reply('Absen dicatat!')

    case 'cekabsen':
      if (!(id in conn.absen)) throw `Tidak ada sesi absen.\nGunakan *.mulaiabsen* untuk memulai.`
      let d = new Date()
      let date = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })
      let list = conn.absen[id][1]
        .map((v, i) => `│ ${i + 1}. @${v.split('@')[0]}`)
        .join('\n')
      return conn.reply(m.chat, `*「 ABSEN 」*\n\nTanggal: ${date}\n${conn.absen[id][2]}\n\n┌ *Yang sudah absen:*\n│ Total: ${list ? list.split('\n').length : 0}\n${list}\n└────`, m, {
        contextInfo: { mentionedJid: conn.absen[id][1] }
      })

    case 'hapusabsen':
    case 'deleteabsen':
      if (!(id in conn.absen)) throw 'Tidak ada sesi absen.'
      delete conn.absen[id]
      return m.reply('Sesi absen telah dihapus.')

    case 'gantiabsen':
      if (!(id in conn.absen)) throw 'Tidak ada sesi absen.'
      let posisi = parseInt(args[0])
      if (!posisi || posisi < 1) throw `Format salah!\nContoh: *.gantiabsen 2*`
      posisi = posisi - 1

      let listAbsen = conn.absen[id][1]
      while (listAbsen.length <= posisi) listAbsen.push(null)

      let posUserSekarang = listAbsen.findIndex(u => u === m.sender)
      let tukarUser = listAbsen[posisi]

      if (posUserSekarang === -1) {
        // Belum absen
        listAbsen[posisi] = m.sender
        return m.reply(tukarUser
          ? `Kamu menggantikan posisi @${tukarUser.split('@')[0]}` 
          : `Kamu mengisi di posisi ke-${posisi + 1}`, 
          null, 
          tukarUser ? { mentions: [tukarUser] } : {})
      } else {
        // Sudah absen
        if (posUserSekarang === posisi) return m.reply('Kamu sudah ada di posisi itu!')
        listAbsen[posUserSekarang] = tukarUser
        listAbsen[posisi] = m.sender
        return m.reply(tukarUser
          ? `Kamu bertukar posisi dengan @${tukarUser.split('@')[0]}`
          : `Kamu pindah ke posisi ke-${posisi + 1}`, 
          null, 
          tukarUser ? { mentions: [tukarUser] } : {})
      }

    default:
      throw 'Perintah tidak dikenali.'
  }
}

handler.command = /^(mulaiabsen|absen|cekabsen|hapusabsen|deleteabsen|gantiabsen)$/i
handler.group = true

export default handler