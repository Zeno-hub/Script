let handler = m => m;

handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
    if (!m.isGroup) return;
    if (m.fromMe) return true;

    if (m.id.startsWith('3EB0') && m.id.length === 22) {
        let chat = global.db.data.chats[m.chat] || {};
        let user = global.db.data.users[m.sender] || {};

        if (!chat.antiBot) return;

        user.selfbotWarning = user.selfbotWarning || 0;
        user.selfbotWarning += 1;

        if (user.selfbotWarning >= 5) {
            await conn.reply(
                m.chat,
                `🚨 *[ BOT LAIN TERDETEKSI ]*\n\n❌ Anda telah melanggar sebanyak 5 kali.\n⛔ SELF BOT ANDA AKAN DIKICK DARI GRUP!`,
                null
            );
            await conn.delay(1500);

            if (!isAdmin && isBotAdmin) {
                await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
            }
            user.selfbotWarning = 0;
        } else {
            await conn.reply(
                m.chat,
                `🚨 *[ BOT LAIN TERDETEKSI ]*\n\n⛔ SELF BOT ANDA JIKA TIDAK MAU DIKICK (${user.selfbotWarning}/5)`,
                null
            );
        }
    }
};

export default handler;