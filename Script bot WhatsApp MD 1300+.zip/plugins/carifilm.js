import https from 'https';
import cheerio from 'cheerio';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    
    if (!text) return m.reply('Masukkan query.');

    m.reply('Tunggu sebentar...');

    async function film(query) {
        return new Promise((resolve, reject) => {
            const url = `https://ruangmoviez.my.id/?s=${query}`;
            
            https.get(url, (resp) => {
                let data = '';
                
                resp.on('data', (chunk) => {
                    data += chunk;
                });
                
                resp.on('end', () => {
                    const $ = cheerio.load(data);
                    const movies = [];

                    $('article.item-infinite').each((index, element) => {
                        const movie = {
                            link: $(element).find('a[itemprop="url"]').attr('href'),
                            title: $(element).find('h2.entry-title a').text(),
                            relTag: $(element).find('a[rel="category tag"]').map((i, el) => $(el).text()).get()
                        };
                        movies.push(movie);
                    });

                    resolve({
                        status: 200,
                        creator: 'Author Name', // Ganti dengan nama penulis yang sesuai
                        result: movies
                    });
                });
            }).on("error", (err) => {
                resolve({
                    status: 404,
                    msg: err.message
                });
            });
        });
    }
    
    let { status, result } = await film(text);
    
    if (status === 404) {
        return m.reply(`Error: ${result.msg}`);
    }

    let cap = `\`Pencarian Film Dari: ${text}\`\n\n`;

    for (let res of result) {
        cap += `*Judul*: ${res.title}\n`;
        cap += `*Link*: ${res.link}\n`;
        cap += `*Genre*: ${res.relTag.join(', ')}\n\n`;
    }

    m.reply(cap);
};

handler.help = ['carifilm'];
handler.tags = ["search"];
handler.command = /^(carifilm)$/i;
handler.register = true;

export default handler;