export async function before(m, { isAdmin, isBotAdmin }) {
  // Memastikan bahwa pesan berasal dari grup
  if (m.isGroup) {
    // Menghindari pemrosesan pesan yang dikirim oleh bot sendiri
    if (m.isBaileys && m.fromMe) return true;

    // Mengambil data chat dan data pengguna dari database
    let chat = global.db.data.chats[m.chat];
    let user = global.db.data.users[m.key.participant];

    // Memeriksa tipe pesan apakah itu video
    let isVideo = m.mtype === 'videoMessage'; // Cek apakah pesan tersebut adalah videoMessage
    let hapus = m.key.participant;  // ID pengirim pesan
    let bang = m.key.id;            // ID pesan yang akan dihapus

    // Jika pengirim adalah admin, beri peringatan saja
    if (isAdmin) {
      if (isVideo) {
        await m.reply("Kamu Admin, Admin Bebas Yakan... 😊");
      }
      return true; // Lanjutkan pemrosesan tanpa menghapus pesan
    }

    // Jika fitur antiVideo diaktifkan dan pesan berupa video
    if (chat.antiVideo && isVideo) {
      // Mengirim pesan peringatan tentang video yang akan dihapus
      let sentMessage = await m.reply(`*Terdeteksi File MP4*\nVideo yang kamu kirim akan dihapus karena admin mengaktifkan fitur antiVideo. Kamu akan diberi warn 📣`);

      // Menghapus pesan video
      await this.sendMessage(m.chat, { 
        delete: { 
          remoteJid: m.chat, 
          fromMe: false, 
          id: bang, 
          participant: hapus 
        } 
      });

      // Menambahkan atau memperbarui peringatan pengguna
      if (!user.warn) user.warn = 0; // Inisialisasi jika belum ada peringatan
      user.warn += 1;  // Tambah 1 peringatan

      // Mengirim pesan peringatan
      await m.reply(`Warn 📣 ke-${user.warn} untuk kamu, jika mencapai 5 Warn kamu akan dikeluarkan..`);

      // Jika peringatan mencapai 5, keluarkan pengguna
      if (user.warn >= 5) {
        // Jika bot admin, kick pengguna
        if (isBotAdmin) {
          await this.groupParticipantsUpdate(m.chat, [hapus], 'remove');
          await m.reply(`Pengguna @${hapus.split('@')[0]} telah di-kick karena mencapai 5 Warn 📣`);

          // Reset peringatan setelah kick
          user.warn = 0;
          await m.reply("Warn 📣 kamu telah di-reset karena telah dikeluarkan dari grup.");
        } else {
          await m.reply('Bot tidak memiliki izin admin untuk mengeluarkan pengguna!');
        }
      }

      return true; // Menghentikan pemrosesan lebih lanjut
    }

    // Memeriksa tipe pesan apakah itu gambar (imageMessage)
    let isFoto = m.mtype === 'imageMessage'; // Cek apakah pesan tersebut adalah imageMessage

    // Jika pengirim adalah admin, beri peringatan saja
    if (isAdmin && isFoto) {
      await m.reply("Kamu Admin, Admin Bebas Yakan... 😊");
      return true; // Lanjutkan pemrosesan tanpa menghapus pesan
    }

    // Jika fitur antiFoto diaktifkan dan pesan berupa gambar
    if (chat.antiFoto && isFoto) {
      // Mengirim pesan peringatan tentang gambar yang akan dihapus
      let sentMessage = await m.reply(`*Terdeteksi File Gambar*\nFoto yang kamu kirim akan dihapus karena admin mengaktifkan fitur antiFoto. Kamu akan diberi warn 📣`);

      // Menghapus pesan gambar
      await this.sendMessage(m.chat, { 
        delete: { 
          remoteJid: m.chat, 
          fromMe: false, 
          id: bang, 
          participant: hapus 
        } 
      });

      // Menambahkan atau memperbarui peringatan pengguna
      if (!user.warn) user.warn = 0; // Inisialisasi jika belum ada peringatan
      user.warn += 1;  // Tambah 1 peringatan

      // Mengirim pesan peringatan
      await m.reply(`Warn 📣 ke-${user.warn} untuk kamu, jika mencapai 5 Warn kamu akan dikeluarkan..`);

      // Jika peringatan mencapai 5, keluarkan pengguna
      if (user.warn >= 5) {
        // Jika bot admin, kick pengguna
        if (isBotAdmin) {
          await this.groupParticipantsUpdate(m.chat, [hapus], 'remove');
          await m.reply(`Pengguna @${hapus.split('@')[0]} telah di-kick karena mencapai 5 Warn 📣`);

          // Reset peringatan setelah kick
          user.warn = 0;
          await m.reply("Warn 📣 kamu telah di-reset karena telah dikeluarkan dari grup.");
        } else {
          await m.reply('Bot tidak memiliki izin admin untuk mengeluarkan pengguna!');
        }
      }

      return true; // Menghentikan pemrosesan lebih lanjut
    }
  }

  return true;  // Lanjutkan ke proses berikutnya
}