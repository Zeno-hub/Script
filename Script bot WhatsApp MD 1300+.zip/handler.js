import { smsg } from './lib/simple.js'
import { format } from 'util'
import { fileURLToPath } from 'url'
import path, { join } from 'path'
import { unwatchFile, watchFile } from 'fs'
import chalk from 'chalk'
import moment from 'moment-timezone'
import DATA from "./system/database/DB_LOCAL.js"
import * as Func from "./system/function.js"
import { failed } from "./system/failed.js"
import { jidNormalizedUser } from '@whiskeysockets/baileys'

global.fixJid = function (id) {
  try {
    if (!id) return null
    return jidNormalizedUser(id)
  } catch {
    return id
  }
}

export async function patchMessage(m) {
  if (!m) return m
  const msg = { ...m }
  if (m.key && typeof m.key === 'object') msg.key = { ...m.key }
  if (m.message && typeof m.message === 'object') msg.message = { ...m.message }

  try { if (msg.chat) msg.chat = fixJid(msg.chat) } catch {}
  try { if (msg.sender) msg.sender = fixJid(msg.sender) } catch {}
  try { if (msg.from) msg.from = fixJid(msg.from) } catch {}
  try { if (msg.key?.remoteJid) msg.key.remoteJid = fixJid(msg.key.remoteJid) } catch {}
  try { if (msg.participant) msg.participant = fixJid(msg.participant) } catch {}
  return msg
}

const isNumber = x => typeof x === 'number' && !isNaN(x)
const delay = ms => (isNumber(ms) ? new Promise(res => setTimeout(res, ms)) : Promise.resolve())

export async function handler(chatUpdate) {
  if (!chatUpdate) return
  this.pushMessage?.(chatUpdate.messages).catch?.(console.error)

  let m = chatUpdate.messages?.[chatUpdate.messages.length - 1]
  if (!m) return
  m = await patchMessage(m)

  if (m.key?.fromMe || m.sender === this.user?.jid) return
  if (global.db.data == null) await global.loadDatabase?.()
    try {
        m = smsg(this, m) || m
        if (!m)
            return
        m.exp = 0
        m.limit = false
        try {
            DATA(m, conn)
        } catch (e) {
            console.error(e)
        }
        
        const detectwhat = m.sender.includes('@lid') ? '@lid' : '@s.whatsapp.net'
const ownerNumbers = global.owner.map(v => (typeof v === 'string' ? v : v[0]).replace(/[^0-9]/g, ''))
const mappedOwners = ownerNumbers.map(v => v + detectwhat)
const isROwner = mappedOwners.includes(m.sender)
const isOwner = isROwner || m.fromMe
const isPrems = isROwner || global.prems.map(v => (typeof v === 'string' ? v : v[0]).replace(/[^0-9]/g, '') + detectwhat).includes(m.sender) || (db.data.users[m.sender].premiumTime > 0 || db.data.users[m.sender].premium === true)
        async function getLidFromJid(id, conn) {
            if (id.endsWith('@lid')) return id
            const res = await conn.onWhatsApp(id).catch(() => [])
            return res[0]?.lid || id
        }
        global.getLidFromJid = getLidFromJid
        const senderLid = await getLidFromJid(m.sender, this)
        const botLid = await getLidFromJid(this.user.jid, this)
        const senderJid = m.sender
        const botJid = this.user.jid
        const groupMetadata = (m.isGroup ? (conn.chats[m.chat] || {}).metadata : {}) || {}
        const participants = m.isGroup ? (groupMetadata.participants || []) : []
        const user = participants.find(p => p.id === senderLid || p.id === senderJid) || {}
        const bot = participants.find(p => p.id === botLid || p.id === botJid) || {}
        const isRAdmin = user?.admin === "superadmin" || false
        const isAdmin = isRAdmin || user?.admin === "admin" || false
        const isBotAdmin = !!bot?.admin || false

        const dbUser = db.data.users, dbChat = db.data.chats, dbBot = db.data.settings
        if (!(m.fromMe || isROwner) && opts['self']) return
        if (opts['pconly'] && m.chat.endsWith('g.us')) return
        if (opts['swonly'] && m.chat !== 'status@broadcast') return
        if (typeof m.text !== 'string') m.text = ''
        if ((m.id.startsWith('3EB0') || m.id.startsWith('HAYASEYUUKA')) && (m.id.length === 27 || m.id.length == 22)) return
        m.exp += Math.ceil(Math.random() * 10)
        let usedPrefix
        let _user = global.db.data && dbUser && dbUser[m.sender]
        const ___dirname = path.join(path.dirname(fileURLToPath(import.meta.url)), './plugins')
        for (let name in global.plugins) {
            let plugin = global.plugins[name]
            if (!plugin)
                continue
            if (plugin.disabled)
                continue
            const __filename = join(___dirname, name)
            if (typeof plugin.all === 'function') {
                try {
                    await plugin.all.call(this, m, {
                    chatUpdate,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    Func,
                    failed,
                    dbUser,
                    dbChat,
                    dbBot,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    __dirname: ___dirname,
                    __filename
                    })
                } catch (e) {
                    console.error(e)
                    for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                        let data = (await conn.onWhatsApp(jid))[0] || {}
                        if (data.exists)
                            m.reply(`❲ SISTEM ERROR ❳

Plugins : ${name}
Pengirim : ${m.sender}
Chat : ${m.chat}
Perintah : ${m.text}

${format(e)}

`.trim(), data.jid)
                    }
                }
            }
            
            if (!opts['restrict'])
                if (plugin.tags && plugin.tags.includes('admin')) {
                    failed('restrict', m, conn)
                    continue
                }
            
                
            const str2Regex = str => str.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&')
            let _prefix = plugin.customPrefix ? plugin.customPrefix : conn.prefix ? conn.prefix : global.prefix
            let match = (_prefix instanceof RegExp ? 
                [[_prefix.exec(m.text), _prefix]] :
                Array.isArray(_prefix) ? 
                    _prefix.map(p => {
                        let re = p instanceof RegExp ? 
                            p :
                            new RegExp(str2Regex(p))
                        return [re.exec(m.text), re]
                    }) :
                    typeof _prefix === 'string' ? 
                        [[new RegExp(str2Regex(_prefix)).exec(m.text), new RegExp(str2Regex(_prefix))]] :
                        [[[], new RegExp]]
            ).find(p => p[1])
            if (typeof plugin.before === 'function') {
                if (await plugin.before.call(this, m, {
                    chatUpdate,
                    match,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    Func,
                    failed,
                    dbChat,
                    dbUser,
                    dbBot,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    __dirname: ___dirname,
                    __filename
                }))
                    continue
            }
            if (typeof plugin !== 'function')
                continue
              if (!opts.noprefix) {
        opts["noprefix"] = false;
      }
let isAcc = (match && match[0] !== null) || (opts["noprefix"] && match && m);

if (isAcc) {
    let result;
    
    if (opts["noprefix"]) {
        result = match ? (match[0] || "")[0] : null;
    } else if (!opts["noprefix"]) {
        result = match ? (match[0] || "")[0] : null;
    } else {
        result = null;
    }

        usedPrefix = result;
        let noPrefix = !result ? m.text : m.text?.replace(result, "");
        let args_v2 = noPrefix.trim().split(/ +/);
        let [command, ...args] = noPrefix.trim().split(" ").filter(v => v);
                args = args || []
                let _args = noPrefix.trim().split` `.slice(1)
                let text = _args.join` `
                
                command = (command || '').toLowerCase()
                let fail = plugin.fail || failed 
                
                const prefixCommand = !result ?
                    plugin.customPrefix || plugin.command :
                    plugin.command;
                let isAccept =
                    (prefixCommand instanceof RegExp && prefixCommand.test(command)) ||
                    (Array.isArray(prefixCommand) &&
                        prefixCommand.some((cmd) =>
                            cmd instanceof RegExp ? cmd.test(command) : cmd === command,
                        )) ||
                    (typeof prefixCommand === "string" && prefixCommand === command);
                m.prefix = !!result;
                usedPrefix = !result ? "" : result;

                if (!isAccept)
                    continue
                m.plugin = name
                if (m.chat in dbChat || m.sender in dbUser) {
                    let chat = dbChat[m.chat]
                    let user = dbUser[m.sender]
                    if (name != 'own-unbanchat.js' && name != 'own-exec.js' && name != 'own-exec2.js' && name != 'own-delete.js' && chat?.isBanned && !isROwner)
                        return 
                    if (name != 'own-unbanuser.js' && user?.banned && !user?.owner)
                        return
                }
                if (!m.isGroup && global.db.data.settings[conn.user.jid].allakses && !Object.values((await conn.groupMetadata(setting.idgc)).participants).find(users => users.id == m.sender)) {
                failed('gconly', m, conn)
                continue 
}
                if (!m.isGroup && opts['gconly'] && !m.chat.endsWith('g.us') && !isROwner) {
                failed('groups', m, conn)
                continue 
                }
                        
                if (!m.isGroup && global.db.data.settings[conn.user.jid].onlyprem && !isPrems) {
                failed('premiumonly', m, conn)
                continue 
}
                if (m.isGroup && dbChat[m.chat].adminonly && !isAdmin) {
                failed('adminonly', m, conn)
                continue 
}
                if (m.isGroup && !db.data.chats[m.chat].games && plugin.tags && plugin.tags.includes("game")) {
                failed('game', m, conn)
                continue
                }
                if (m.isGroup && !db.data.chats[m.chat].rpgs && plugin.tags && plugin.tags.includes("rpg")) {
                failed('rpg', m, conn)
                continue
                }
                if (plugin.rowner && !isROwner) { 
                    failed('rowner', m, conn)
                    continue
                }
                if (plugin.owner && !isOwner) { 
                    failed('owner', m, conn)
                    continue
                }
                if (plugin.mods && !isMods) {
                    failed('mods', m, conn)
                    continue
                }
                if (plugin.premium && !isPrems) {
                    failed('premium', m, conn)
                    continue
                }
                if (plugin.group && !m.isGroup) {
                    failed('group', m, conn)
                    continue
                }
                if (plugin.botAdmin && !isBotAdmin) { 
                    failed('botAdmin', m, conn)
                    continue
                }
                if (plugin.admin && !isAdmin) {
                    failed('admin', m, conn)
                    continue
                }
                if (plugin.private && m.isGroup) { 
                    failed('private', m, conn)
                    continue
                }
                if (plugin.register == true && _user.registered == false) {
                    failed('unreg', m, conn)
                    continue
                }
                m.isCommand = true
                let xp = 'exp' in plugin ? parseInt(plugin.exp) : 23 
                m.exp += xp
                if (!isPrems && plugin.limit && dbUser[m.sender].limit < plugin.limit * 1) {
                    this.reply(m.chat, `Limit kamu sudah  mencapai batas\n*segera beli limit atau premium ke owner*`, m)
                    continue
                }
                if (plugin.level > _user.level) {
                    this.reply(m.chat, `Diperlukan Level ${plugin.level} Untuk Menggunakan Perintah Ini\n*Level Kamu:* ${_user.level}`, m)
                    continue 
                }
                let extra = {
                    match,
                    usedPrefix,
                    noPrefix,
                    args,
                    command,
                    text,
                    Func,
                    failed,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    dbBot,
                    dbUser,
                    dbChat,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    __dirname: ___dirname,
                    __filename
                }
                try {
                    await plugin.call(this, m, extra)
                    if (!isPrems) {
                        m.limit = m.limit || plugin.limit || false
                        }
                } catch (e) {
                    m.error = e
                    console.error(e)
                    if (e) {
                        let text = format(e)
                        for (let key of Object.values(global.APIKeys))
                            text = text.replace(new RegExp(key, 'g'), '#HIDDEN#')
                        if (e.name)
                            for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                                let data = (await conn.onWhatsApp(jid))[0] || {}
                                if (data.exists)
                                    m.reply(`❲ REPORT SISTEM ❳
                                    
Plugins : ${m.plugin}
Pengirim : ${m.sender}
Chat : ${m.chat}
Perintah : ${usedPrefix}${command} ${args.join(' ')}

${text}

`.trim(), data.jid)
                            }
                        m.reply(text)
                    }
                } finally {
                    if (typeof plugin.after === 'function') {
                        try {
                            await plugin.after.call(this, m, extra)
                        } catch (e) {
                            console.error(e)
                        }
                    }
                }
                break
            }
        }
    } catch (e) {
        console.error(e)
    } finally {
        let user, stats = global.db.data.stats
        let dbUser = global.db.data.users
        if (m) {
            if (m.sender && (user = db.data.users[m.sender])) {
                user.exp += m.exp
                user.limit -= m.limit * 1
                if (m.limit) return m.reply(`🔖 Limit telah digunakan: ${m.limit * 1}\nTersisa: ${dbUser[m.sender].limit}`)
            }

            let stat
            if (m.plugin) {
              let rn = ['composing']
              await this.sendPresenceUpdate(rn, m.chat)
                let now = +new Date
                if (m.plugin in stats) {
                    stat = stats[m.plugin]
                    if (!isNumber(stat.total)) stat.total = 1
                    if (!isNumber(stat.success)) stat.success = m.error != null ? 0 : 1
                    if (!isNumber(stat.last)) stat.last = now
                    if (!isNumber(stat.lastSuccess)) stat.lastSuccess = m.error != null ? 0 : now
                } else stat = stats[m.plugin] = {
                    total: 1,
                    success: m.error != null ? 0 : 1,
                    last: now,
                    lastSuccess: m.error != null ? 0 : now
                }
                stat.total += 1
                
                stat.last = now
                if (m.error == null) {
                    stat.success += 1
                    stat.lastSuccess = now
                }
                
            }
        }

        try {
            if (!opts['noprint']) await (await import(`./lib/print.js`)).default(m, conn)
        } catch (e) {
            console.log(m, m.quoted, e)
        }
        if (global.db.data.settings[this.user.jid].autoread) await this.readMessages([m.key])
    }
}

let file = global.__filename(import.meta.url, true)
watchFile(file, async () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'handler.js'"))
    if (global.reloadHandler) console.log(await global.reloadHandler())
})
